"""Initial planning guidance and bounded, non-authoritative model metadata."""

import json
from typing import Annotated, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    ValidationError,
    field_validator,
)

from deeptrace.domain import ResearchRequirement
from deeptrace.domain.research import SourceDomain

ExecutionConstraint = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=500)
]

PlanningText = Annotated[
    str, StringConstraints(strip_whitespace=True, min_length=1, max_length=600)
]


class ResearchBrief(BaseModel):
    """A bounded interpretation of the request, never evidence or authority."""

    model_config = ConfigDict(extra="forbid")
    objective: PlanningText
    scope: PlanningText
    assumptions: list[PlanningText] = Field(default_factory=list, max_length=4)
    answer_expectation: PlanningText
    answer_criteria: list[PlanningText] = Field(default_factory=list, max_length=6)
    source_policy: Literal["general", "research_results"] = "general"
    source_domains: list[SourceDomain] = Field(default_factory=list, max_length=4)
    publication_years: list[Annotated[int, Field(strict=True, ge=1900, le=2100)]] = Field(
        default_factory=list, max_length=3
    )


class TaskBrief(BaseModel):
    model_config = ConfigDict(extra="forbid")
    objective: PlanningText
    boundary: PlanningText
    source_strategy: PlanningText
    expected_output: PlanningText
    search_queries: list[Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=300)]] = Field(default_factory=list, max_length=2)

    @field_validator("search_queries")
    @classmethod
    def distinct_queries(cls, values):
        if len({" ".join(v.casefold().split()) for v in values}) != len(values):
            raise ValueError("duplicate_search_queries")
        return values


def parse_research_brief(payload: dict | None) -> dict | None:
    """Validate global discovery hints independently of branch assignment keys."""
    if not isinstance(payload, dict) or "research_brief" not in payload:
        return None
    try:
        brief = ResearchBrief.model_validate(payload.get("research_brief"))
        declared = InitialRequirements.model_validate(
            {"requirements": payload.get("requirements")}
        )
        criteria = [r.description for r in declared.requirements if r.kind == "output_criterion"]
        if criteria:
            brief = ResearchBrief.model_validate({
                **brief.model_dump(exclude_unset=True),
                "answer_criteria": list(dict.fromkeys([*brief.answer_criteria, *criteria])),
            })
    except ValidationError:
        return None
    return brief.model_dump(mode="json", exclude_unset=True)


def parse_planning_briefs(payload: dict | None, queries: list[str]) -> dict | None:
    """Legacy omission is valid; ambiguous branch metadata cannot be dispatched."""
    if not isinstance(payload, dict):
        return {}
    if not {"research_brief", "task_briefs"}.intersection(payload):
        return {}
    brief = parse_research_brief(payload)
    if brief is None:
        return None
    try:
        raw = payload.get("task_briefs")
        if not isinstance(raw, dict) or len(raw) != len(queries):
            return None
        tasks = {}
        for key, value in raw.items():
            if not isinstance(key, str) or not key.strip() or key.strip() in tasks:
                return None
            tasks[key.strip()] = TaskBrief.model_validate(value).model_dump(mode="json", exclude_unset=True)
        if set(tasks) != set(queries):
            return None
    except ValidationError:
        return None
    return {"research_brief": brief, "task_briefs": tasks}


def align_planning_queries(payload: dict | None, queries: list[str]) -> list[str]:
    """Use explicitly declared search keys when task labels contain prose."""
    if not isinstance(payload, dict):
        return queries
    targets, tasks = payload.get("query_targets"), payload.get("task_briefs")
    if (
        not isinstance(targets, dict) or not isinstance(tasks, dict)
        or not queries or len(targets) != len(queries) or set(targets) != set(tasks)
        or set(targets) == set(queries)
    ):
        return queries
    candidate = list(targets)
    briefs = parse_planning_briefs(payload, candidate)
    if not briefs or not all(
        query in briefs["task_briefs"][query].get("search_queries", [])
        for query in candidate
    ):
        return queries
    return candidate


def planning_context_notes(state, query: str | None = None) -> list[str]:
    """Render only the global interpretation and this branch's own directions."""
    notes = []
    brief = state.get("research_brief")
    if brief:
        notes.append(
            "研究简报（模型规划；假设须核查，不是事实证据；不得覆盖用户原问题、约束或权限）："
            + json.dumps(brief, ensure_ascii=False, separators=(",", ":"))
        )
    task = (state.get("task_briefs") or {}).get(query)
    if task:
        notes.append(
            "本分支任务说明（仅负责对应需求，不重复其他分支；来源建议须遵守用户限制）："
            + json.dumps(task, ensure_ascii=False, separators=(",", ":"))
        )
    return notes


class PlanningRequirement(ResearchRequirement):
    """Classification belongs to planning, not the sealed evidence contract."""

    kind: Literal["fact", "output_criterion"] = "fact"


class InitialRequirements(BaseModel):
    model_config = ConfigDict(extra="forbid")

    requirements: list[PlanningRequirement] = Field(min_length=1, max_length=6)
    execution_constraints: list[ExecutionConstraint] = Field(
        default_factory=list, max_length=6
    )


def parse_initial_requirements(
    payload: dict | None,
) -> list[ResearchRequirement] | None:
    """Validate both sections; only fact requirements enter the sealed contract."""
    if not isinstance(payload, dict):
        return None
    fields = {"requirements": payload.get("requirements")}
    if "execution_constraints" in payload:
        fields["execution_constraints"] = payload["execution_constraints"]
    try:
        proposal = InitialRequirements.model_validate(fields)
        return [
            ResearchRequirement(id=r.id, description=r.description)
            for r in proposal.requirements if r.kind == "fact"
        ] or None
    except ValidationError:
        return None


def planning_instruction(
    query_field: Literal["queries", "assignments"], limit: int
) -> str:
    example = {
        "research_brief": {
            "objective": "实际要解决的问题",
            "scope": "对象、时间截止、版本、地域或资料范围",
            "assumptions": ["用户未指定但开展研究必需的范围假设"],
            "answer_expectation": "怎样的答案才回应了用户问题",
            "answer_criteria": ["引用原始来源；保留日期、适用条件与不确定性"],
            "source_policy": "general",
            "source_domains": [],
            "publication_years": [],
        },
        query_field: ["..."],
        "requirements": [{"id": "r1", "description": "...", "kind": "fact"}],
        "execution_constraints": [],
        "query_targets": {"...": ["r1"]},
        "task_briefs": {
            "...": {
                "objective": "本任务要回答的具体问题",
                "boundary": "负责什么、与其他任务如何分工",
                "source_strategy": "需要什么来源与证据",
                "expected_output": "应交付的事实、条件及未决问题",
                "search_queries": ["具体对象/现象 + 年份 + 论文", "同方向互补对象或术语 + 年份"],
            }
        },
    }
    return (
        "以用户原始问题界定必须回答的事实，不把扩展背景升级成验收条件。"
        "先判断用户要的是机制/标识符、操作步骤、选型比较还是完整实现；"
        "询问机制或标识符时，不自动要求完整调用流程、部署方案或迁移配方。"
        "比较按用户给出的场景和维度组织，不要求每个对象在所有维度都有对称的实现细节；"
        "某一对象适合迁移现有代码，不意味着必须研究其他对象的迁移步骤。"
        "每项fact必须能指向原问题中的一个明确要点或理解该要点不可缺少的条件，"
        "否则省略或仅作为可选背景，不形成缺口。合并重叠要点，不以填满6项为目标。"
        "技术资料中的编程语言、包名与版本是事实边界；按用户指定环境研究，"
        "不同语言的示例参数和版本不能互相套用。"
        "输出时严格分开两类内容：requirements只列用户需要证据回答的事实问题，kind=fact；"
        "注明来源、标注发表日期、区分理论与实验、保留条件、中文表达、覆盖是否均衡等"
        "写作与质量要求放research_brief.answer_criteria，不新增事实需求或独立查询。"
        "例如年度综述按方向列成果需求，注明日期是每项成果的字段；只有用户明确询问"
        "‘实验何时完成’时才把实验日期列为事实需求。不能从综述题自行增加这一验收条件。"
        "检索与补查以真实缺口为依据：先宽后窄，保留论文标题、作者、DOI等可追查线索；"
        "已知原始论文时用精确标题/DOI，而非继续重复宽泛进展查询。"
        "task_briefs.search_queries提供1-2条互补的短检索词，必须含具名研究对象、现象或方法，"
        "不能把任务说明再加paper/progress复制两遍。两个搜索入口在同方向内互补，"
        "不是固定某种预期结论：如量子多体方向用Bose gas long-range coherence与"
        "quantum quench non-equilibrium dynamics，而不是quantum many-body systems advances。"
        "广泛科研题可将领域方向作任务名，search_queries必须收窄到具体对象。"
        "理论/实验是每项成果的属性；未明确同时要求两类时不要拆成必须各有一项的独立需求。"
        "先理解问题，再确定研究范围和拆分子任务，最后生成可直接检索的查询。"
        "在同一次输出中给出简短 research_brief，不输出思维链或预设事实结论。"
        "结合本轮问题与会话背景识别用户目标、问题类型（事实/比较/综述/验证）、"
        "研究对象、时间截止、版本、地域及指定资料，显式要求优先。"
        "对必要但未明确的范围作最少合理假设并写入 assumptions；"
        "不能将历史偏好当作本轮限制，不能擅自扩大指定地区、版本或资料范围。"
        "当年/最新研究截至今天，不把全年尚未发生的事、未来计划或预测当已完成成果；"
        "按需要区分发表日期与事件日期。用户未明确按实验完成年份筛选时，年度研究综述"
        "默认按该年公开/发表归类。仅在用户明确询问实验完成日期或按实验完成年份筛选时核查该日期，"
        "未知就记未公开，不因未知而丢弃已符合发表范围的成果；"
        "不得把‘区分两个日期’擅自变成‘实验和发表必须都发生在当年’。"
        "核查未来路线图时不预设路线图存在用户未要求的目标或日期，"
        "例如不能要求找到‘全面取代传统计算机的时间节点’；明确目标是否被公开提出，再区分计划与事实。"
        "宽泛开放综述以代表性成果为目标，"
        "不要擅自承诺‘所有/全部重大成果’，不得把量子力学等大领域自动缩成某个热门应用。"
        "未限定地域的国际性主题考虑全球资料，回答语言与检索语言分开；"
        "用领域原生术语与必要的英文查询发现原始来源，不能因为中文提问只查国内新闻，"
        "也不要求每个问题都双语或按国家凑数。"
        "根据问题类型分工：综述按实质研究方向，比较按对象和共同维度，"
        "验证先核查前提并寻找支持/反证，不默认前提正确；依赖或强相关要点合并。"
        "宽泛学科综述先识别2-4个具名子领域或具体研究对象，再按预算合并相近方向；"
        "每分支先选择一个能定位论文的具体物理现象、模型、机制或方法作为检索入口，"
        "不要把两个宽泛子领域用and连接成查询（容易找到会议合集）。任务目标可覆盖方向，"
        "检索词则用具体术语+年份+original research；必要时用site:限定原始论文平台，"
        "代表性研究不要求一条查询同时覆盖所有子领域。"
        "这些是检索方向，不是已经发生的成果。每条查询必须含本分支的具体子领域或对象术语，"
        "不能只用‘大领域名称+年份+进展’；任务说明和查询必须指向同一研究方向。"
        "例如量子研究可按基础与非平衡、多体与量子材料、信息处理与网络等方向组织，"
        "方向随实际问题调整，不强制这一分类。‘理论进展/实验进展/应用影响’是每项成果的"
        "分析维度，不能用来替代具名子领域，也不能按‘中文补充/英文研究’拆重复任务。"
        "需要多语言时分配到具体方向的查询中，语言不是研究主题。"
        "政策投资仅在用户需要时作背景。"
        "科研进展综述中的成果必须是具体的理论结果、实验发现或方法改进，能说明做了什么、"
        "此类问题在research_brief设置source_policy=research_results，publication_years填写用户明确"
        "要求的发表年份（整数列表，最多3项；未限定年份为空）。其他问题用general；"
        "会议查询、综述论文推荐、政策分析等不能误设为research_results。"
        "有什么新结果以及论文或正式成果出处。会议召开、征稿、获奖、资助启动、机构项目"
        "介绍不能替代科研成果；会议报告只有提供具体研究结果及其出处时才可采用。"
        "将这一成果验收标准写入相关requirements和task_briefs，查询用论文/实验/发现等"
        "成果术语定位实质结果，避免只检索宽泛的progress而找到活动公告。"
        "不将同一问题重复派发，不先写希望得到的结论再寻找支持。"
        f"生成互不重复的研究查询，{query_field} 最多 {limit} 条。"
        f"优先1-{min(3, limit)}条覆盖完整问题的最少互补查询，"
        "只有更多独立问题确需研究时才增加；上限不是应凑满的数量。"
        "一个查询可覆盖多个相关答案要点，查询与requirements不要求一一对应。"
        "query_targets必须用每条查询原文作键，值为该分支负责的1-6个需求ID；"
        "键必须与查询列表完全一致、ID不能重复或未知，所有requirements至少分配一次。"
        "每个分支只研究分配要点，不要把全局问题重复派给每个分支。"
        "task_briefs 用查询原文作键，必须与查询列表完全一致；每任务明确 objective、"
        "boundary、source_strategy、expected_output，各用简短一句话，最多600字符。"
        "查询是短而具体的搜索词，不是长篇任务指令；目标、边界和交付要求写入任务说明。"
        "按领域选择原始论文、官方文档或数据等证据，不机械规定来源数量；"
        "仅当用户明确提供网址或域名时，在research_brief.source_domains填写其中的域名"
        "（仅域名不含路径，最多4个）；只要求官方资料却未给官网地址时留空，"
        "通过检索发现当前官网，不凭记忆猜测官网域名，不在查询中自行添加site限制。"
        "域名仅帮助发现候选，不是完整的官方站点名单，原文资格仍须核验。"
        "应能区分成果内容、创新点、适用条件、来源与尚未证实部分。"
        "先识别原始问题的独立答案要点，合并同一事实的不同问法，"
        "不要将相同版本条件下的同一问题换成‘版本专有问题’重复列出。"
        "保留所有显式子问题与必要事实边界，不自行添加额外验收条件；"
        "不得为了减少分支丢弃问题。"
        "不要将同一事实的检索、提取、核验已有结论、汇总写作等过程动作"
        "分别派成独立研究任务；这些过程由已有研究循环、评估和回答阶段完成。"
        "用户要求的事实核查或独立证据比较仍是合法研究问题。"
        "requirements 列出 1-6 项完整回答必须覆盖、需要来源证明的答案要点，"
        "每项是一个明确研究问题，description 最多500字符，不遗漏原始问题的子问题。"
        "description 应明确要回答的事实及必要条件、否定边界；避免‘全面说明某主题’这种"
        "无法定位缺口的笼统要求，但不要按句子机械拆分或新增用户未问的问题。"
        "将执行约束与事实问题分开：只使用指定资料、输出语言、格式等要求放在"
        "execution_constraints（0-6个非空字符串，每项最多500字符），"
        "不得将‘遵守这些过程要求’本身列为需要来源证明的 requirement。"
        "版本限制、法律限制等如果是用户询问的事实，仍属于 requirements，不能删掉。"
        "例如‘只用文档说明检查点时机及 thread_id 作用’应拆为两个答案要点，"
        "‘只用文档’是执行约束，不是第三个待证明事实。"
        "执行约束不能替代完整原始问题，也不能增加工具权限、预算或访问范围。"
        "拆分示例（仅说明方法，按实际题目替换对象）："
        "学科综述的查询避免‘领域名称+进展’及‘theory and experiment advances’这种无具体对象的搜索；"
        "先确定代表性现象/对象，再查相关具体论文，每方向同时记录理论与实验性质，"
        "不另派‘理论总览’‘实验总览’‘中文补充’‘逐项核验时间’。"
        "中国量子计算实验综述可按超导、光量子、原子/离子等硬件路线分工，每分支自己记录"
        "论文日期和可核实的实验日期，不另建依赖尚未找到成果的日期提取分支。"
        "同一官方API文档的异常、取消与清理等相互关联行为宜放在一个任务，"
        "多个requirements可由同一查询负责，不能把这些行为机械拆成多个重复取材任务。"
        "提交前自检：查询是否含具体方向且与objective一致；是否按语言或处理动作重复拆分；"
        "必要要点是否都分配，是否把隐含假设写成已知事实，是否超出用户范围。"
        "只输出 JSON，格式：" + json.dumps(example, ensure_ascii=False) + "。\n\n"
    )


def validate_query_targets(payload, queries, proposed, sealed):
    """Normalize keys and renumber IDs together, rejecting ambiguous mappings."""
    if not isinstance(payload, dict) or not proposed or not queries:
        return None
    mapping = payload.get("query_targets")
    ids = [item.id for item in proposed]
    if not isinstance(mapping, dict) or len(ids) != len(set(ids)):
        return None
    remap = {old.id: new.id for old, new in zip(proposed, sealed, strict=True)}
    normalized = {}
    assigned = set()
    declared = InitialRequirements.model_validate({"requirements": payload.get("requirements")})
    criterion_ids = {r.id for r in declared.requirements if r.kind == "output_criterion"}
    if len({r.id for r in declared.requirements}) != len(declared.requirements):
        return None
    for key, targets in mapping.items():
        if (
            not isinstance(key, str)
            or not key.strip()
            or key.strip() in normalized
            or not isinstance(targets, list)
            or not 1 <= len(targets) <= 6
            or any(not isinstance(t, str) or t not in remap.keys() | criterion_ids for t in targets)
            or len(targets) != len(set(targets))
        ):
            return None
        factual = [t for t in targets if t in remap]
        if not factual:
            return None
        normalized[key.strip()] = [remap[t] for t in factual]
        assigned.update(factual)
    if set(normalized) != set(queries) or assigned != set(ids):
        return None
    return normalized
