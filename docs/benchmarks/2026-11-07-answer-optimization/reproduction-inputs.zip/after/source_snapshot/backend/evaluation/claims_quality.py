"""Claim-level groundedness and citation-accuracy scorer; no Ragas dependency.

Consumes the same quality_eval.json v2 export as ragas_quality.py and adds two
LLM-as-judge metrics:

- claim_groundedness: extract atomic claims from the answer, judge each against
  the selected evidence; value = grounded claims / checked claims.
- citation_accuracy: for each sentence/source citation use, judge whether the cited
  evidence body actually supports the citing sentence; value = supported
  citations / checked citations.

Every judge call is metered by the shared AttemptLedger; scores are cached with
integrity checks and the run can be resumed. Unmeasurable metrics stay
not_applicable; failures stay error; nothing is zero-imputed.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import math
import os
import re
from importlib.metadata import version
from pathlib import Path

import eval_common
from eval_common import (
    AttemptLedger,
    atomic_json,
    cache_key,
    digest,
    unmeasured,
    validate_export,
)

METRICS = ("claim_groundedness", "citation_accuracy")
ADAPTER_VERSION = "claims-v2"

# Same marker contract as responses/citations.py final compacted answers.
_MARKER_PATTERN = re.compile(r"\[(\d{1,3})\]")
_SENTENCE_ENDINGS = "。！？.!?\n"

_CLAIM_TEXT_CHARS = 200
_CITATION_SENTENCE_CHARS = 2000
_QUALITY_INPUT_CHARS = 100_000
_CALL_TIMEOUT_SECONDS = 120

_CLAIMS_RUBRIC = (
    "请从下面的研究回答中提取全部原子论断（claim），并逐条判断该论断"
    "是否被给定的证据材料支撑。\n"
    "要求：\n"
    "1. 每条论断是回答中独立、可验证的陈述；相同论断只保留一条。\n"
    "2. grounded 为 true 当且仅当证据材料中有内容直接支撑该论断；"
    "证据只相关但不支撑、或缺少对应内容时为 false。\n"
    '3. 只输出 JSON：{"claims": [{"text": "论断内容", "grounded": true}, ...]}，'
    "不要输出其他文字。"
)

_CITATION_RUBRIC = (
    "判断下方“来源正文”是否支撑“引用句”中的论断。研究问题仅作背景。\n"
    "只有当来源正文包含直接支撑引用句的内容时 supported 才为 true；"
    "来源只相关但不支撑、或缺少对应内容时为 false。\n"
    '只输出 JSON：{"supported": true} 或 {"supported": false}，'
    "不要输出其他文字。"
)


def parse_json_object(text):
    if not isinstance(text, str):
        return None
    candidate = text.strip()
    try:
        parsed = json.loads(candidate)
    except json.JSONDecodeError:
        start = candidate.find("{")
        end = candidate.rfind("}")
        if 0 <= start < end:
            try:
                parsed = json.loads(candidate[start : end + 1])
            except json.JSONDecodeError:
                return None
        else:
            return None
    return parsed if isinstance(parsed, dict) else None


def _content(response):
    choices = getattr(response, "choices", [])
    message = (
        getattr(getattr(choices[0], "message", None), "content", None)
        if choices
        else None
    )
    return message if isinstance(message, str) else None


async def _call_judge(call, prompt, *, model, max_tokens):
    """One metered judge call with a single bounded JSON parse retry."""
    for _ in range(2):
        response = await call(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            max_tokens=max_tokens,
        )
        parsed = parse_json_object(_content(response))
        if parsed is not None:
            return parsed
    return None


def _sentence_spans(text):
    """Sentence spans; a marker directly after ending punctuation stays attached.

    ``First claim.[2] Second...`` keeps ``[2]`` with ``First claim.`` so the
    marker cannot drift onto the following sentence.
    """
    spans = []
    start = index = 0
    length = len(text)
    while index < length:
        if text[index] in _SENTENCE_ENDINGS:
            end = index + 1
            while True:
                match = _MARKER_PATTERN.match(text, end)
                if match is None:
                    break
                end = match.end()
            spans.append((start, end))
            start = index = end
        else:
            index += 1
    if start < length:
        spans.append((start, length))
    return spans


def _selected_contexts(record):
    return [
        entry["body"]
        for entry in record.get("evidence", [])
        if isinstance(entry, dict)
        and entry.get("selected_for_outcome")
        and isinstance(entry.get("body"), str)
        and entry["body"].strip()
    ]


def _citation_matches(answer):
    """Independent stdlib-only masking: the scorer image excludes production.

    Keep offsets and newlines so citation spans still address the raw answer.
    Code indices never become citation uses, including unclosed fences.
    """
    masked, fence = list(answer), None
    for match in re.finditer(r"(?m)^ {0,3}(`{3,}|~{3,})([^\n]*)(?:\n|$)", answer):
        marker, suffix = match[1], match[2].strip()
        if fence is None:
            if marker[0] != "`" or "`" not in suffix:
                fence = (match.start(), marker)
        elif marker[0] == fence[1][0] and len(marker) >= len(fence[1]) and not suffix:
            first, _ = fence
            for index in range(first, match.end()):
                if masked[index] != "\n":
                    masked[index] = " "
            fence = None
    if fence:
        for index in range(fence[0], len(answer)):
            if masked[index] != "\n":
                masked[index] = " "
    for match in re.finditer(r"(?<!`)(`+)(?!`)(.*?)(?<!`)\1(?!`)", "".join(masked), re.DOTALL):
        for index in range(match.start(), match.end()):
            if masked[index] != "\n":
                masked[index] = " "
    return list(_MARKER_PATTERN.finditer("".join(masked)))


def _citation_items(record, *, max_citations):
    """Deterministic marker -> sentence -> evidence preparation; no judge calls.

    Returns (items, total_uses, outcome): outcome is None on success, or a
    (status, reason) pair explaining why the metric is unmeasurable.
    """
    answer = record.get("answer", "")
    cited_ids = list(record.get("cited_evidence_ids") or [])
    if not isinstance(answer, str):
        return None, 0, ("error", "invalid_answer_type")
    markers = [
        (match.start(), int(match.group(1)))
        for match in _citation_matches(answer)
    ]
    if not markers or not cited_ids:
        return None, 0, ("not_applicable", "no_citations")
    for _, number in markers:
        if not 1 <= number <= len(cited_ids):
            return None, 0, ("error", "marker_out_of_range")
    evidence_by_id = {
        entry.get("id"): entry
        for entry in record.get("evidence", [])
        if isinstance(entry, dict)
    }
    spans = _sentence_spans(answer)
    sentences, order = {}, []
    for position, number in markers:
        for start, end in spans:
            if start <= position < end:
                key = (start, end, number)
                if key not in sentences:
                    sentence = answer[start:end].strip()
                    offsets = {m.start() for m in _citation_matches(sentence)}
                    sentences[key] = _MARKER_PATTERN.sub(
                        lambda m, visible_offsets=offsets: "" if m.start() in visible_offsets else m.group(), sentence,
                    )
                    order.append(key)
                break
    total_uses = len(order)
    items = []
    for key in order[:max_citations]:
        number = key[2]
        evidence_id = cited_ids[number - 1]
        entry = evidence_by_id.get(evidence_id)
        if entry is None:
            return None, total_uses, ("error", "cited_evidence_missing")
        body = entry.get("body")
        if not isinstance(body, str) or not body.strip():
            return None, total_uses, ("not_applicable", "empty_cited_body")
        if len(sentences[key]) > _CITATION_SENTENCE_CHARS:
            return None, total_uses, ("not_applicable", "citation_sentence_size_limit")
        items.append(
            {
                "number": number,
                "evidence_id": evidence_id,
                "title": entry.get("title") or "",
                "url": entry.get("url") or "",
                "sentence": sentences[key],
                "body": body,
            }
        )
    return items, total_uses, None


async def score_claim_groundedness(sample, call, *, model, max_tokens, max_claims):
    record = sample["record"]
    answer = record.get("answer", "")
    question = record.get("question", "")
    if (
        not isinstance(answer, str)
        or not isinstance(question, str)
        or not answer.strip()
        or not question.strip()
    ):
        return unmeasured("not_applicable", "missing_question_or_answer")
    contexts = _selected_contexts(record)
    if not contexts or record.get("artifact_errors"):
        return unmeasured("not_applicable", "missing_or_incomplete_selected_evidence")
    if sum(map(len, [answer, question, *contexts])) > _QUALITY_INPUT_CHARS:
        return unmeasured("not_applicable", "quality_input_size_limit")
    prompt = (
        f"研究问题：{question}\n\n"
        f"研究回答：\n{answer}\n\n"
        "证据材料：\n"
        + "\n\n".join(
            f"[材料{index + 1}]\n{body}" for index, body in enumerate(contexts)
        )
        + "\n\n"
        + _CLAIMS_RUBRIC
    )
    try:
        async with asyncio.timeout(_CALL_TIMEOUT_SECONDS):
            parsed = await _call_judge(call, prompt, model=model, max_tokens=max_tokens)
    except Exception as exc:  # noqa: BLE001 — scoring failures are retained, not zero
        return unmeasured("error", type(exc).__name__)
    if parsed is None:
        return unmeasured("error", "judge_parse")
    raw_claims = parsed.get("claims")
    if not isinstance(raw_claims, list):
        return unmeasured("error", "invalid_claims")
    claims = []
    malformed = 0
    for item in raw_claims:
        if (
            isinstance(item, dict)
            and isinstance(item.get("text"), str)
            and item["text"].strip()
            and isinstance(item.get("grounded"), bool)
        ):
            claims.append(
                {
                    "text": item["text"][:_CLAIM_TEXT_CHARS],
                    "grounded": item["grounded"],
                }
            )
        else:
            malformed += 1
    if not claims:
        return unmeasured("error", "empty_claims")
    truncated = len(claims) > max_claims
    claims = claims[:max_claims]
    grounded = sum(claim["grounded"] for claim in claims)
    value = grounded / len(claims)
    if not math.isfinite(value) or not 0 <= value <= 1:
        return unmeasured("error", "invalid_metric_value")
    return {
        "status": "ok",
        "value": value,
        "reason": None,
        "details": {
            "claims": claims,
            "claim_count": len(claims),
            "grounded_count": grounded,
            "claims_truncated": truncated,
            "malformed_claims": malformed,
        },
    }


async def score_citation_accuracy(sample, call, *, model, max_tokens, max_citations):
    record = sample["record"]
    answer = record.get("answer", "")
    question = record.get("question", "")
    if (
        not isinstance(answer, str)
        or not isinstance(question, str)
        or not answer.strip()
        or not question.strip()
    ):
        return unmeasured("not_applicable", "missing_question_or_answer")
    items, total_uses, outcome = _citation_items(record, max_citations=max_citations)
    if outcome is not None:
        status, reason = outcome
        return unmeasured(status, reason)
    prompts = [
        f"研究问题：{question}\n\n"
        f"引用句：{item['sentence']}\n\n"
        f"来源标题：{item['title'] or '（无标题）'}\n"
        f"来源URL：{item['url'] or '（无）'}\n"
        f"来源正文：\n{item['body']}\n\n"
        + _CITATION_RUBRIC
        for item in items
    ]
    if any(len(prompt) > _QUALITY_INPUT_CHARS for prompt in prompts):
        return unmeasured("not_applicable", "quality_input_size_limit")
    verdicts = []
    try:
        async with asyncio.timeout(_CALL_TIMEOUT_SECONDS):
            for item, prompt in zip(items, prompts, strict=True):
                parsed = await _call_judge(
                    call, prompt, model=model, max_tokens=max_tokens
                )
                if parsed is None or not isinstance(parsed.get("supported"), bool):
                    return unmeasured("error", "judge_parse")
                verdicts.append(
                    {
                        "number": item["number"],
                        "evidence_id": item["evidence_id"],
                        "sentence": item["sentence"],
                        "supported": parsed["supported"],
                    }
                )
    except Exception as exc:  # noqa: BLE001 — scoring failures are retained, not zero
        return unmeasured("error", type(exc).__name__)
    supported = sum(verdict["supported"] for verdict in verdicts)
    return {
        "status": "ok",
        "value": supported / len(verdicts),
        "reason": None,
        "details": {
            "citations": verdicts,
            "unique_citation_count": len({m.group(1) for m in _citation_matches(answer)}),
            "citation_use_count": total_uses,
            "checked_citation_count": len(verdicts),
            "supported_citation_count": supported,
            "citations_truncated": total_uses > len(verdicts),
            "score_scope": "sampled_citation_uses" if total_uses > len(verdicts) else "all_citation_uses",
        },
    }


async def score_metric(
    sample, name, call, *, model, max_tokens, max_claims, max_citations
):
    if name not in METRICS:
        raise ValueError("unknown metric")
    if name == "claim_groundedness":
        return await score_claim_groundedness(
            sample, call, model=model, max_tokens=max_tokens, max_claims=max_claims
        )
    return await score_citation_accuracy(
        sample, call, model=model, max_tokens=max_tokens, max_citations=max_citations
    )


async def evaluate(
    payload, output, judge, credentials, max_attempts, *, max_claims, max_citations
):
    from openai import AsyncOpenAI

    ledger = AttemptLedger(output / "attempts.json", max_attempts)
    async with AsyncOpenAI(
        api_key=credentials["key"],
        base_url=credentials["url"],
        max_retries=0,
        timeout=60,
    ) as client:
        raw = client.chat.completions.create

        async def metered(**kwargs):
            for key, value in judge.get("request_options", {}).items():
                kwargs.setdefault(key, value)
            return await ledger.invoke(raw, **kwargs)

        client.chat.completions.create = metered
        results = []
        for sample in payload["samples"]:
            row = {
                "run_id": sample["record"]["run_id"],
                "question_id": sample["record"]["question_id"],
                "mode": sample["record"]["mode"],
                "system_status": sample["record"]["status"],
                "metrics": {},
            }
            for name in METRICS:
                key = cache_key(
                    sample,
                    name,
                    judge,
                    adapter_version=ADAPTER_VERSION,
                    scorer_path=__file__,
                )
                target, claim = output / f"{key}.json", output / f"{key}.claim"
                if target.exists():
                    saved = json.loads(target.read_text(encoding="utf-8"))
                    if saved["key"] != key or saved["result_sha256"] != digest(
                        saved["result"]
                    ):
                        raise ValueError("quality cache integrity mismatch")
                    result = saved["result"]
                else:
                    if claim.exists():
                        raise ValueError(
                            "interrupted quality metric requires manual inspection"
                        )
                    claim.touch(exist_ok=False)
                    result = await score_metric(
                        sample,
                        name,
                        metered,
                        model=judge["model"],
                        max_tokens=judge["max_tokens"],
                        max_claims=max_claims,
                        max_citations=max_citations,
                    )
                    atomic_json(
                        target,
                        {"key": key, "result": result, "result_sha256": digest(result)},
                    )
                    claim.unlink()
                row["metrics"][name] = result
                # Persist each finished score; later judge failure cannot lose it.
                atomic_json(
                    output / "progress.json",
                    {"completed": results, "current": row, "usage": ledger.snapshot()},
                )
            results.append(row)
        report = {
            "schema_version": 1,
            "experiment_identity": payload["identity_sha256"],
            "judge": judge,
            "goal_view": "question_answer_selected_evidence_and_citations",
            "results": results,
            "usage": ledger.snapshot(),
            "human_review": None,
        }
        atomic_json(output / "claims_scores.json", report)
        return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--max-provider-attempts", required=True, type=int)
    parser.add_argument("--env-file", default=".env")
    parser.add_argument("--judge-model")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--max-claims", type=int, default=40)
    parser.add_argument("--max-citations", type=int, default=16)
    args = parser.parse_args(argv)
    if args.max_provider_attempts < 1:
        parser.error("positive judge limit required")
    if args.max_claims < 1 or args.max_citations < 1:
        parser.error("positive claim and citation limits required")
    input_path = Path(args.input)
    if input_path.stat().st_size > 64 * 1024 * 1024:
        parser.error("quality export exceeds 64 MiB")
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    validate_export(payload)
    config = eval_common.env_config(args.env_file)
    key, url = config.get("OPENAI_API_KEY"), config.get("OPENAI_BASE_URL")
    model = args.judge_model or config.get("OPENAI_MODEL")
    if not key or not url or not model:
        parser.error("judge credentials, base URL and model required")
    try:
        parsed = eval_common.credential_free_endpoint(url)
    except ValueError:
        parser.error("credential-free HTTP(S) endpoint required")
    judge = {
        "model": model,
        "provider": f"{parsed.scheme}://{parsed.netloc}",
        "endpoint_sha256": digest(url.rstrip("/")),
        "temperature": 0,
        "max_tokens": 2048,
        "sdk_retries": 0,
        "parse_retries": 1,
        "same_model_as_agent": model == payload["manifest"]["model"]["name"],
        "openai": version("openai"),
        "adapter": ADAPTER_VERSION,
        "scorer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "common_sha256": hashlib.sha256(
            Path(eval_common.__file__).read_bytes()
        ).hexdigest(),
        "request_options": eval_common.judge_request_options(config, model),
    }
    identity = {
        "input_sha256": digest(payload),
        "judge": judge,
        "max_provider_attempts": args.max_provider_attempts,
        "max_claims": args.max_claims,
        "max_citations": args.max_citations,
    }
    output = Path(args.out)
    if output.is_symlink() or any(p.is_symlink() for p in output.absolute().parents):
        parser.error("symlink output refused")
    output = output.resolve()
    if args.resume:
        if (
            not (output / "identity.json").exists()
            or json.loads((output / "identity.json").read_text(encoding="utf-8"))
            != identity
        ):
            parser.error("quality identity mismatch")
    elif output.exists() and any(output.iterdir()):
        parser.error("nonempty quality directory refused")
    output.mkdir(parents=True, exist_ok=True)
    lock = output / ".writer.lock"
    try:
        with lock.open("x", encoding="utf-8") as handle:
            handle.write(str(os.getpid()))
    except FileExistsError:
        parser.error("quality writer lock exists; inspect before recovery")
    try:
        if not args.resume:
            atomic_json(output / "identity.json", identity)
        report = asyncio.run(
            evaluate(
                payload,
                output,
                judge,
                {"key": key, "url": url},
                args.max_provider_attempts,
                max_claims=args.max_claims,
                max_citations=args.max_citations,
            )
        )
    except Exception as exc:  # noqa: BLE001 — never print raw provider exception text
        print(json.dumps({"status": "error", "error": type(exc).__name__}))
        return 1
    finally:
        lock.unlink()
    # Only bounded, credential-free summary printed, not prompts or exceptions.
    print(
        json.dumps(
            {"results": report["results"], "usage": report["usage"]},
            ensure_ascii=False,
            indent=2,
        )
    )
    return int(
        any(
            m["status"] == "error"
            for r in report["results"]
            for m in r["metrics"].values()
        )
    )


if __name__ == "__main__":
    raise SystemExit(main())
