"""Shared, offline provenance boundary for comparison and regression reports."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path

from deeptrace.eval.trajectory import _content_hash


def _finite_float(value):
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("nonfinite JSON number")
    return number


def _reject_constant(value):
    raise ValueError("nonfinite JSON constant")


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def read_json(path):
    target = Path(path)
    if target.stat().st_size > 64 * 1024 * 1024:
        raise ValueError("analysis input exceeds 64 MiB")
    return json.loads(
        target.read_text(encoding="utf-8"),
        parse_constant=_reject_constant,
        parse_float=_finite_float,
        object_pairs_hook=_unique_object,
    )


@dataclass(frozen=True)
class AnalysisInputs:
    payload: dict
    metadata: dict
    records: list[dict]
    scores: list[dict]
    provenance: dict
    metric_judges: dict


def load_analysis_inputs(input_path, score_paths, metadata_path) -> AnalysisInputs:
    payload, metadata = read_json(input_path), read_json(metadata_path)
    if not all(isinstance(item, dict) for item in (payload, metadata)):
        raise ValueError("JSON objects required")
    manifest = payload.get("manifest")
    if (
        payload.get("schema_version") != 2
        or not isinstance(manifest, dict)
        or _content_hash(manifest) != payload.get("identity_sha256")
    ):
        raise ValueError("experiment manifest integrity mismatch")
    if not score_paths:
        raise ValueError("at least one score source required")
    merged, metric_judges, judges = {}, {}, []
    human_review = None
    for scores_path in score_paths:
        scores = read_json(scores_path)
        if not isinstance(scores, dict):
            raise ValueError("score JSON object required")
        if scores.get("experiment_identity") != payload["identity_sha256"]:
            raise ValueError("judge experiment identity mismatch")
        identity = read_json(Path(scores_path).parent / "identity.json")
        if (
            not isinstance(identity, dict)
            or identity.get("input_sha256") != _content_hash(payload)
            or identity.get("judge") != scores.get("judge")
            or not isinstance(scores.get("judge"), dict)
            or not scores["judge"]
        ):
            raise ValueError("exact judged input or judge identity mismatch")
        scoring_identity = {
            "judge": scores["judge"],
            "configuration": {
                key: value
                for key, value in identity.items()
                if key not in {"input_sha256", "judge", "max_provider_attempts"}
            },
        }
        results = scores.get("results")
        if not isinstance(results, list):
            raise ValueError("judge results array required")
        for row in results:
            if not isinstance(row, dict) or not isinstance(row.get("metrics"), dict):
                raise ValueError("judge record object required")
            run_id = row.get("run_id")
            if not isinstance(run_id, str) or not run_id:
                raise ValueError("judge record object required")
            target = merged.setdefault(
                run_id,
                {
                    "run_id": run_id,
                    "mode": row.get("mode"),
                    "question_id": row.get("question_id"),
                    "system_status": row.get("system_status"),
                    "metrics": {},
                },
            )
            if any(target[key] != row.get(key) for key in ("mode", "question_id")):
                raise ValueError("judge run identity mismatch")
            for name, value in row["metrics"].items():
                if name in target["metrics"]:
                    raise ValueError("duplicate metric source")
                if name in metric_judges and metric_judges[name] != scoring_identity:
                    raise ValueError("inconsistent judge for metric")
                metric_judges[name] = scoring_identity
                target["metrics"][name] = value
        judges.append(
            {
                "scores_sha256": hashlib.sha256(
                    Path(scores_path).read_bytes()
                ).hexdigest(),
                "judged_input_sha256": identity["input_sha256"],
                **scoring_identity,
            }
        )
        if scores.get("human_review") is not None:
            human_review = scores["human_review"]
    for name in ("dataset_sha256", "corpus_sha256"):
        if name not in manifest or metadata.get(name) != manifest[name]:
            raise ValueError("analysis metadata asset identity mismatch")
    samples = payload.get("samples")
    if not isinstance(samples, list) or any(
        not isinstance(s, dict) or not isinstance(s.get("record"), dict)
        for s in samples
    ):
        raise ValueError("sample record objects required")
    return AnalysisInputs(
        payload=payload,
        metadata=metadata,
        records=[s["record"] for s in samples],
        scores=list(merged.values()),
        metric_judges=metric_judges,
        provenance={
            "experiment_identity": payload["identity_sha256"],
            "input_sha256": _content_hash(payload),
            "scores": judges,
            "metadata_sha256": _content_hash(metadata),
            "human_review": human_review,
        },
    )
