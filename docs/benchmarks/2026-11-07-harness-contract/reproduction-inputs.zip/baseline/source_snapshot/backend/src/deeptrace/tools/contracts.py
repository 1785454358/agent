from __future__ import annotations

import inspect
import math
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

from deeptrace.domain import ToolName
from deeptrace.domain.tools import MAX_TOOL_PREVIEW_LENGTH, CustomToolName
from deeptrace.tools.evidence_store import EvidenceDraft

if TYPE_CHECKING:
    from deeptrace.tools.policy import EvidenceAuthorization, ToolCaller


class ToolCapability(StrEnum):
    FILE_READ = 'file_read'
    WEB_SEARCH = "web_search"
    PAGE_FETCH = "page_fetch"
    MEMORY_READ = "memory_read"
    MEMORY_WRITE = "memory_write"
    EVIDENCE_READ = "evidence_read"


class CachePolicy(StrEnum):
    NONE = "none"
    SUCCESS = "success"


@dataclass(frozen=True)
class ToolCallContext:
    """Host-only identity and evidence grants, never model tool arguments."""

    tenant_id: str
    run_id: str
    thread_id: str
    caller: ToolCaller
    evidence_authorization: EvidenceAuthorization | None


ToolHandler = Callable[[BaseModel, ToolCallContext], Awaitable[Any]]
ToolPreflight = Callable[[BaseModel, ToolCallContext], Awaitable[None]]


@dataclass(frozen=True)
class ToolAdapterResult:
    """Normalized adapter output before state-safe projection."""

    ok: bool = True
    error_code: str | None = None
    message: str | None = None
    preview: str = ""
    data_ref: str | None = None
    evidence: EvidenceDraft | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.ok, bool):
            raise TypeError("ok must be a bool")
        if self.ok == (self.error_code is not None):
            raise ValueError("adapter success/error fields are inconsistent")
        if self.message is not None and not isinstance(self.message, str):
            raise TypeError("message must be a string or None")
        if self.ok and self.message is not None:
            raise ValueError("successful adapter results cannot carry a message")
        if not isinstance(self.preview, str):
            raise TypeError("preview must be a string")
        if self.data_ref is not None and not isinstance(self.data_ref, str):
            raise TypeError("data_ref must be a string or None")
        if self.evidence is not None and not isinstance(self.evidence, EvidenceDraft):
            raise TypeError("evidence must be an EvidenceDraft or None")
        if not self.ok and (self.preview or self.data_ref or self.evidence is not None):
            raise ValueError("failed adapter results cannot carry payloads")

    @classmethod
    def failure(
        cls, error_code: str, *, message: str | None = None
    ) -> ToolAdapterResult:
        if not isinstance(error_code, str) or not error_code.strip():
            raise ValueError("error_code must be a non-empty string")
        if message is not None and not isinstance(message, str):
            raise TypeError("message must be a string or None")
        return cls(ok=False, error_code=error_code.strip(), message=message)


@dataclass(frozen=True)
class ToolSpec:
    name: ToolName | CustomToolName
    argument_model: type[BaseModel]
    handler: ToolHandler
    capability: ToolCapability
    cache_policy: CachePolicy
    timeout_seconds: float
    preview_limit: int
    stores_evidence: bool
    preflight: ToolPreflight | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.name, (ToolName, CustomToolName)):
            raise TypeError("spec name must be a ToolName or CustomToolName")
        if not (
            isinstance(self.argument_model, type)
            and issubclass(self.argument_model, BaseModel)
        ):
            raise TypeError("argument_model must be a Pydantic BaseModel type")
        if not callable(self.handler) or not (
            inspect.iscoroutinefunction(self.handler)
            # Inspect coroutine callable instances, not ordinary callability.
            or inspect.iscoroutinefunction(getattr(self.handler, "__call__", None))  # noqa: B004
        ):
            raise TypeError("handler must be async")
        if not isinstance(self.capability, ToolCapability):
            raise TypeError("capability must be a ToolCapability")
        if not isinstance(self.cache_policy, CachePolicy):
            raise TypeError("cache_policy must be a CachePolicy")
        if not isinstance(self.timeout_seconds, (int, float)) or isinstance(
            self.timeout_seconds, bool
        ):
            raise TypeError("timeout_seconds must be numeric")
        if not math.isfinite(self.timeout_seconds):
            raise ValueError("timeout_seconds must be finite")
        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be greater than zero")
        if not isinstance(self.preview_limit, int) or isinstance(
            self.preview_limit, bool
        ):
            raise TypeError("preview_limit must be an int")
        if self.preview_limit < 0:
            raise ValueError("preview_limit cannot be negative")
        if self.preview_limit > MAX_TOOL_PREVIEW_LENGTH:
            raise ValueError(f"preview_limit cannot exceed {MAX_TOOL_PREVIEW_LENGTH}")
        if not isinstance(self.stores_evidence, bool):
            raise TypeError("stores_evidence must be a bool")
        if self.preflight is not None and not (
            inspect.iscoroutinefunction(self.preflight)
            or inspect.iscoroutinefunction(getattr(self.preflight, "__call__", None))  # noqa: B004
        ):
            raise TypeError("preflight must be async")
