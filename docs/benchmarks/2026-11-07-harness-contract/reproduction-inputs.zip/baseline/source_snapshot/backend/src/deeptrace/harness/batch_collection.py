"""Host-directed acquisition through the existing authenticated tool boundary."""

from __future__ import annotations

import hashlib
import json
from datetime import date
from itertools import zip_longest
from typing import Any

from langchain_core.messages import AIMessage

from deeptrace.domain import EvidenceLifecycleStatus
from deeptrace.harness.agent_state import (
    AgentExecutorState,
    AgentTodo,
    TodoStatus,
    topic_input,
)
from deeptrace.harness.agent_tools import execute_batch
from deeptrace.harness.context import HarnessContext
from deeptrace.tools.scraper.research_links import is_paper_link, primary_links_in_body


def stage_todos(completed: int) -> list[AgentTodo]:
    return [
        AgentTodo(
            content=label,
            status=TodoStatus.COMPLETED if i < completed else TodoStatus.PENDING,
        )
        for i, label in enumerate(("检索资料", "抓取原文", "读取证据"))
    ]


def merge_updates(state, updates):
    """Match AgentExecutorState reducers when several host waves share a node."""
    result = {**state, **updates}
    for key in ("messages", "errors"):
        result[key] = [*(state.get(key) or []), *(updates.get(key) or [])]
    for key in ("evidence_ids", "attempted_urls"):
        result[key] = list(
            dict.fromkeys([*(state.get(key) or []), *(updates.get(key) or [])])
        )
    result["executed_steps"] = state.get("executed_steps", 0) + updates.get(
        "executed_steps", 0
    )
    return result


def node_delta(original, current):
    result = dict(current)
    for key in ("messages", "errors"):
        result[key] = (current.get(key) or [])[len(original.get(key) or []) :]
    for key in ("evidence_ids", "attempted_urls"):
        result[key] = [
            v for v in current.get(key) or [] if v not in (original.get(key) or [])
        ]
    result["executed_steps"] = current.get("executed_steps", 0) - original.get(
        "executed_steps", 0
    )
    for key in ("topic_input", "outcome"):
        result.pop(key, None)
    return result


async def host_tools(
    state: AgentExecutorState,
    context: HarnessContext,
    calls: list[tuple[str, dict[str, Any]]],
    *,
    concurrency: int = 4,
):
    identity = len(state.get("messages") or [])
    requests = []
    for i, (name, args) in enumerate(calls):
        key = f"{identity}:{i}:{name}:{json.dumps(args, sort_keys=True)}"
        requests.append(
            {
                "name": name,
                "args": args,
                "id": "batch-" + hashlib.sha256(key.encode()).hexdigest()[:32],
            }
        )
    dispatch = AIMessage(content="", tool_calls=requests)
    updated = await execute_batch(
        {**state, "messages": [*(state.get("messages") or []), dispatch]},
        context,
        max_concurrency=concurrency,
    )
    return {**updated, "messages": [dispatch, *updated["messages"]]}


async def search_sources(state: AgentExecutorState, context: HarnessContext):
    task = topic_input(state)
    if getattr(context.model_gateway, "research_exhausted", False):
        return {"stop_reason": "budget_exhausted", "todos": stage_todos(0)}
    seeds = task.search_queries or [task.query]
    calls = [("search_web", {"query": query, "limit": 8})
             for query in list(dict.fromkeys(seeds))[:2]]
    if task.source_policy == "research_results":
        calls = [("search_web", {"query": seeds[-1], "limit": 8})]
        # One complementary discovery pass, parallel and still subject to the
        # shared gateway budget. Preserve base results for recall.
        refined = seeds[0] if task.search_queries else (
            task.query[:900] + " original research paper -conference -workshop -review"
        )
        options = {"query": refined, "limit": 8, "search_depth": "advanced"}
        if task.publication_years:
            first = date(min(task.publication_years), 1, 1)
            last = min(
                date(max(task.publication_years), 12, 31), context.clock.now().date()
            )
            if first > last:
                return {
                    "candidate_urls": [],
                    "source_candidates": [],
                    "todos": stage_todos(1)[:1],
                }
            options.update(start_date=first.isoformat(), end_date=last.isoformat())
        if task.search_queries and len(seeds) == 1:
            calls = [("search_web", options)]
        else:
            calls.insert(0, ("search_web", options))
    if task.source_domains:
        sites = " OR ".join(f"site:{domain}" for domain in task.source_domains)
        if len(task.source_domains) > 1:
            sites = f"({sites})"
        # Planner domains are discovery hints, not a complete or verified list
        # of official hosts. Keep primary discovery open for migrated docs;
        # use the other slot for the hint, never expand beyond two searches.
        name, args = calls[-1]
        hinted = (name, {**args, "query": sites + " " + args["query"]})
        if len(calls) == 1:
            calls.append(hinted)
        else:
            calls[-1] = hinted
    updated = await host_tools(state, context, calls)
    candidates, rows = [], []
    result_groups = []
    for message in updated["messages"]:
        if message.type != "tool":
            continue
        payload = json.loads(message.content)
        if payload.get("ok"):
            result_groups.append(json.loads(payload["preview"]).get("results", []))
    for rank in zip_longest(*result_groups):
        for row in rank:
            if row:
                url = row.get("url")
                if isinstance(url, str) and url not in candidates:
                    candidates.append(url)
                    rows.append(
                        {
                            "id": f"c{len(candidates)}",
                            "url": url[:2048],
                            "title": str(row.get("title") or "")[:300],
                            "snippet": str(row.get("snippet") or "")[:1000],
                            "discovery_date": row.get("discovery_date"),
                        }
                    )
    cap = 12 if task.source_policy == "research_results" else 8
    return {
        **updated,
        "candidate_urls": candidates[:cap],
        "source_candidates": rows[:cap],
        "todos": stage_todos(1) if candidates else stage_todos(1)[:1],
    }


async def fetch_sources(
    state: AgentExecutorState,
    context: HarnessContext,
    *,
    source_target: int = 3,
    concurrency: int = 4,
):
    task = topic_input(state)
    target = min(source_target, task.max_pages)
    known = {}
    for identity in task.authorized_evidence_ids:
        try:
            record = await context.evidence_store.get(context.workspace_id, identity)
        except KeyError:
            continue
        if record.status is EvidenceLifecycleStatus.ACTIVE:
            known[record.canonical_url] = record.id
    current = dict(state)
    selected = []
    candidates = list(state.get("candidate_urls") or [])
    while candidates and len(selected) < target and not current.get("stop_reason"):
        if getattr(context.model_gateway, "research_exhausted", False):
            current["stop_reason"] = "budget_exhausted"
            break
        wave = []
        while candidates and len(selected) + len(wave) < target:
            url = candidates.pop(0)
            if url in known:
                if known[url] not in selected:
                    selected.append(known[url])
            elif url not in (current.get("attempted_urls") or []):
                wave.append(("fetch_page", {"url": url}))
        if wave:
            updated = await host_tools(current, context, wave, concurrency=concurrency)
            current = merge_updates(current, updated)
            for identity in updated["evidence_ids"]:
                if identity not in selected:
                    selected.append(identity)
    if selected:
        if task.source_policy == "research_results" and not current.get("stop_reason"):
            # Follow one explicit original-paper anchor per secondary page.
            # Gateway authorization comes from the actually fetched page body.
            primary_calls = []
            seen_links = set()
            remaining = max(0, task.max_pages - current.get("pages_fetched", 0))
            for identity in selected:
                record = await context.evidence_store.get(context.workspace_id, identity)
                if is_paper_link(record.canonical_url):
                    continue
                body = await context.evidence_store.read_body(context.workspace_id, identity)
                links = [u for u in primary_links_in_body(body)
                         if u in (current.get("seen_urls") or [])
                         and u not in seen_links
                         and u not in (current.get("attempted_urls") or [])]
                if links and len(primary_calls) < min(target, remaining):
                    primary_calls.append(("fetch_page", {"url": links[0]}))
                    seen_links.add(links[0])
            if primary_calls:
                updated = await host_tools(current, context, primary_calls, concurrency=concurrency)
                current = merge_updates(current, updated)
                originals = list(dict.fromkeys(updated.get("evidence_ids") or []))
                if originals:
                    selected = list(dict.fromkeys([*originals, *selected]))[:target]
        todos = stage_todos(2)
    else:
        attempted_stages = 2 if state.get("candidate_urls") else 1
        todos = stage_todos(2)[:attempted_stages]
    return {
        **node_delta(state, current),
        "batch_selected_ids": selected,
        "todos": todos,
    }


async def read_sources(
    state: AgentExecutorState,
    context: HarnessContext,
    *,
    concurrency: int = 4,
):
    task = topic_input(state)
    identities = state.get("batch_selected_ids") or []
    if not identities or state.get("stop_reason"):
        return {}
    calls = []
    for identity in identities:
        if task.source_policy == "research_results":
            # A keyword query can rank a long bibliography above the abstract.
            # Keep the article opening and a focused result range, within 3000 chars.
            calls.extend(
                [
                    (
                        "read_evidence",
                        {"evidence_id": identity, "start": 0, "limit": 2000},
                    ),
                    (
                        "read_evidence",
                        {"evidence_id": identity, "query": task.query, "limit": 1000},
                    ),
                ]
            )
        else:
            reading = state.get("batch_read_queries") or {}
            queries = [reading.get(r.id, r.description) for r in task.requirements
                       if not task.target_requirement_ids or r.id in task.target_requirement_ids]
            for query in list(dict.fromkeys(queries or [task.query]))[:6]:
                calls.append(("read_evidence", {
                    "evidence_id": identity, "query": query, "limit": 3000,
                }))
    updated = await host_tools(
        state,
        context,
        calls,
        concurrency=concurrency,
    )
    previews = []
    for message in updated["messages"]:
        if message.type == "tool":
            payload = json.loads(message.content)
            if payload.get("ok"):
                preview = json.loads(payload["preview"])
                if preview.get("passages"):
                    record = await context.evidence_store.get(
                        context.workspace_id, preview["evidence_id"]
                    )
                    preview.update(
                        url=record.canonical_url,
                        title=record.title,
                        published_at=record.published_at.isoformat()
                        if record.published_at
                        else None,
                    )
                    previews.append(preview)
    # Todos track host steps; actual tool observations retain failed reads.
    return {**updated, "batch_read_previews": previews, "todos": stage_todos(3)}
