"""Controlled writer probe: python -m deeptrace.eval.writer_benchmark --help.

Uses raw, pinned documents; reference spans/answers never enter generation.
This isolates writing over fixed evidence, not live retrieval or research quality.
"""

import argparse
import asyncio
import json
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from time import perf_counter

from deeptrace.application.model_provider import build_model_gateway
from deeptrace.config import Settings
from deeptrace.domain import ResponseInput, ResponseMode
from deeptrace.eval.answer_quality import (
    assess_answer,
    paired_quality,
    select_quality_tasks,
)
from deeptrace.eval.artifacts import atomic_json
from deeptrace.eval.assets import default_benchmark_path, load_benchmark
from deeptrace.eval.env import build_eval_context
from deeptrace.eval.experiment import provider_endpoint_hash, source_identity
from deeptrace.eval.telemetry import MeteredChatModel, ModelTelemetry, RequestCounter
from deeptrace.eval.trajectory import _content_hash
from deeptrace.harness.model_gateway import ChatModelGateway
from deeptrace.responses.graph import build_answer_graph
from deeptrace.tools.evidence_store import EvidenceDraft


class CapturedGateway:
    def __init__(self, inner):
        self.inner = inner
        self.calls = []

    async def invoke(self, *, role, messages, tools=None):
        row = {"role": role, "messages": [str(m.content) for m in messages]}
        self.calls.append(row)
        kwargs = {"tools": tools} if tools is not None else {}
        response = await self.inner.invoke(role=role, messages=messages, **kwargs)
        row["response"] = str(response.content)
        row["provider_model"] = (response.response_metadata or {}).get("model_name")
        row["usage_metadata"] = response.usage_metadata
        return response


def probe_gateway(settings, shared_counter, *, max_calls=3):
    telemetry = ModelTelemetry()

    def factory(model, **kwargs):
        return ChatModelGateway(
            MeteredChatModel(
                model, telemetry, RequestCounter(max_calls), shared_counter
            ),
            **kwargs,
        )

    return CapturedGateway(build_model_gateway(settings, factory)), telemetry


async def generate_answer(assets, task, gateway, *, review=False):
    """Only public question and preselected raw source documents reach Writer."""
    env = build_eval_context(
        assets.corpus,
        model_gateway=gateway,
        run_id="writer-probe",
        memory_enabled=False,
    )
    ids = []
    by_id = {doc.doc_id: doc for doc in assets.corpus.documents()}
    for source_id in task.source_ids:
        doc = by_id[source_id]
        record = await env.evidence_store.ingest(
            env.context.workspace_id,
            EvidenceDraft(
                canonical_url=doc.url,
                title=doc.title,
                media_type="text/plain",
                body=doc.body,
                fetched_at=datetime(2026, 10, 2, tzinfo=UTC),
                source_quality=1.0,
            ),
        )
        ids.append(record.id)
    payload = ResponseInput(
        question=task.question,
        response_mode=ResponseMode.ANSWER,
        active_evidence_ids=ids,
    )
    try:
        result = await build_answer_graph().ainvoke(
            {"response_input": payload}, context=replace(env.context, response_fact_review=review)
        )
        outcome = result["outcome"]
        # The exact source block actually sent, after response context allocation.
        prompt = gateway.calls[-1]["messages"][-1]
        if "ANSWER_REVIEW_JSON:\n" in prompt:
            sources = "\n\n".join(json.loads(
                prompt.split("ANSWER_REVIEW_JSON:\n", 1)[1]
            )["original_passages"])
        else:
            sources = prompt.split("以下是本轮已加载的全部资料", 1)[-1].rsplit(
                "\n只输出 JSON：", 1
            )[0]
        return outcome, sources
    finally:
        await env.aclose()


async def run_probe(args):
    assets = load_benchmark(default_benchmark_path(), split="dev")
    tasks = select_quality_tasks(assets)
    if args.task:
        unknown = set(args.task) - {task.id for task in tasks}
        if unknown:
            raise ValueError("unknown development task ID")
        tasks = [task for task in tasks if task.id in args.task]
    settings = Settings.from_env()
    writer_settings = replace(
        settings,
        model_thinking=args.thinking,
        openai_model=args.model or settings.openai_model,
    )
    judge_settings = replace(settings, model_thinking="disabled")
    shared = RequestCounter(args.max_calls)
    output = Path(args.out)
    output.mkdir(parents=True, exist_ok=False)
    report = {
        "schema_version": 1,
        "kind": "fixed-document-writer-probe",
        "materials_identity": _content_hash(
            {
                "benchmark": assets.identity,
                "tasks": [task.id for task in tasks],
            }
        ),
        "model": writer_settings.openai_model,
        "thinking": args.thinking,
        "review_enabled": args.review,
        "max_output_tokens": writer_settings.openai_max_tokens,
        "temperature": 0,
        "judge_model": judge_settings.openai_model,
        "judge_thinking": "disabled",
        "endpoint_sha256": provider_endpoint_hash(settings.openai_base_url),
        "source_files": source_identity(Path(__file__).resolve().parents[4]),
        "max_calls": args.max_calls,
        "records": [],
        "limitations": [
            f"One development item per category; {len(tasks)} tasks, one sample each, no held-out accuracy claim.",
            "Raw documents preselected by benchmark source IDs; retrieval/research are excluded; final review is explicitly configured.",
            "Judge uses the configured base model, blinded to arm; self-judging bias remains.",
            "Generation and judge usage are separate; failures and missing scores remain visible.",
            "Depth/legibility scores are model judgements, not independently adjudicated facts.",
        ],
    }
    for task in tasks:
        writer, writer_usage = probe_gateway(writer_settings, shared)
        judge, judge_usage = probe_gateway(judge_settings, shared, max_calls=1)
        row = {
            "question_id": task.id,
            "category": task.category,
            "scores": None,
            "answer": "",
            "error": None,
            "judge_error": None,
        }
        started = perf_counter()
        try:
            outcome, sources = await generate_answer(assets, task, writer, review=args.review)
            row.update(
                answer=outcome.content,
                partial_reason=outcome.partial_reason,
                writer_visible_sources=sources,
            )
        except Exception as exc:  # noqa: BLE001 - retain per-case failures; cancellation propagates
            row["error"] = type(exc).__name__
        row["writer_seconds"] = round(perf_counter() - started, 3)
        if row["answer"]:
            try:
                row["scores"] = await assess_answer(
                    judge,
                    task=task,
                    answer=row["answer"],
                    sources=row["writer_visible_sources"],
                )
            except Exception as exc:  # noqa: BLE001 - judge errors remain unscored, never zero
                row["judge_error"] = type(exc).__name__
        row.update(
            writer_usage=writer_usage.snapshot(),
            judge_usage=judge_usage.snapshot(),
            writer_calls=writer.calls,
            judge_calls=judge.calls,
        )
        report["records"].append(row)
        report["provider_attempts"] = shared.used
        atomic_json(output / "results.json", report)
        print(
            f"{task.id}: answer={len(row['answer'])} chars, error={row['error']}, judge={row['judge_error']}",
            flush=True,
        )
    if args.baseline:
        previous = json.loads(Path(args.baseline).read_text(encoding="utf-8"))
        report["paired_quality"] = paired_quality(previous, report)
        atomic_json(output / "results.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out", required=True, help="new output directory; never overwrite"
    )
    parser.add_argument(
        "--thinking",
        choices=["disabled", "enabled", "provider_default"],
        default="disabled",
    )
    parser.add_argument(
        "--model", help="explicit provider model ID; otherwise current configured model"
    )
    parser.add_argument(
        "--task", action="append", help="restrict to selected development task IDs"
    )
    parser.add_argument("--max-calls", type=int, default=24)
    parser.add_argument("--review", action="store_true", help="include production final fact review")
    parser.add_argument(
        "--baseline", help="results.json from the same fixed tasks and materials"
    )
    args = parser.parse_args(argv)
    if not 1 <= args.max_calls <= 100:
        parser.error("max-calls must be 1..100")
    asyncio.run(run_probe(args))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
