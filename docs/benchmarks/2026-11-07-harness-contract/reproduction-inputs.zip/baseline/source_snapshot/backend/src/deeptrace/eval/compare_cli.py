"""Offline: python -m deeptrace.eval.compare_cli --help."""

from __future__ import annotations

import argparse
from pathlib import Path

from deeptrace.eval.analysis_inputs import load_analysis_inputs
from deeptrace.eval.artifacts import atomic_json
from deeptrace.eval.comparison import compare_records, render_comparison


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="quality_eval.json v2")
    parser.add_argument(
        "--scores",
        required=True,
        action="append",
        help="one or more scores files; judge metrics merge per run_id",
    )
    parser.add_argument(
        "--metadata",
        required=True,
        help="asset hashes and explicit per-question dataset/split/kind/category",
    )
    parser.add_argument("--out", required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--resamples", type=int, default=2000)
    args = parser.parse_args(argv)
    try:
        inputs = load_analysis_inputs(args.input, args.scores, args.metadata)
        report = compare_records(
            inputs.records,
            inputs.scores,
            metadata=inputs.metadata["questions"],
            seed=args.seed,
            resamples=args.resamples,
        )
        report["provenance"] = inputs.provenance
        output = Path(args.out)
        if output.is_symlink() or any(
            p.is_symlink() for p in output.absolute().parents
        ):
            raise ValueError("analysis output symlink refused")
        if output.exists() and any(output.iterdir()):
            raise ValueError("nonempty analysis directory refused")
        output.mkdir(parents=True, exist_ok=True)
        atomic_json(output / "comparison.json", report)
        (output / "comparison.md").write_text(
            render_comparison(report), encoding="utf-8"
        )
    except (ValueError, KeyError, TypeError, OSError) as exc:
        parser.error(
            type(exc).__name__ + ": invalid analysis identity, input or output"
        )
    print(render_comparison(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
