"""Controlled version/strategy regression gates over independently scored trials."""

from __future__ import annotations

from collections import defaultdict
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from deeptrace.eval.analysis_inputs import AnalysisInputs
from deeptrace.eval.comparison import METRICS, compare_records
from deeptrace.eval.trajectory import _content_hash


class QualityRule(BaseModel):
    model_config = ConfigDict(
        extra="forbid", frozen=True, strict=True, allow_inf_nan=False
    )

    max_drop: float = Field(ge=0, le=1)
    max_task_drop: float | None = Field(default=None, ge=0, le=1)


class RegressionPolicy(BaseModel):
    model_config = ConfigDict(
        extra="forbid", frozen=True, strict=True, allow_inf_nan=False
    )

    schema_version: Literal[1]
    name: str = Field(min_length=1, max_length=100)
    min_paired_tasks: int = Field(ge=2, le=10_000)
    min_score_coverage: float = Field(gt=0, le=1)
    max_completion_rate_drop: float = Field(ge=0, le=1)
    max_answered_rate_drop: float = Field(ge=0, le=1)
    max_latency_ratio: float | None = Field(default=None, gt=0)
    metrics: dict[str, QualityRule] = Field(min_length=1, max_length=len(METRICS))

    @field_validator("metrics")
    @classmethod
    def known_metrics(cls, value):
        if set(value) - set(METRICS):
            raise ValueError("unsupported gate metric")
        return value


CONTROL_FIELDS = (
    "schema_version",
    "dataset_sha256",
    "corpus_sha256",
    "model",
    "limits",
    "response_mode",
    "response_max_content_chars",
    "context_allocator",
    "research_context_policy",
    "evidence_policy",
    "repeats",
    "tools_backend",
    "memory_backend",
    "python_version",
    "installed_versions",
)


def _select_trials(inputs: AnalysisInputs, mode: str):
    manifest = inputs.payload["manifest"]
    if manifest.get("schema_version") != 2:
        raise ValueError("manifest schema version 2 required")
    if (
        not isinstance(manifest.get("source_files"), dict)
        or not manifest["source_files"]
    ):
        raise ValueError("source snapshot identity required")
    if (
        manifest.get("tools_backend") != "frozen_local_corpus"
        or manifest.get("memory_backend") != "disabled"
    ):
        raise ValueError("controlled gate requires frozen corpus and disabled memory")
    modes = manifest.get("modes")
    if (
        not isinstance(modes, list)
        or not modes
        or any(not isinstance(m, str) or not m for m in modes)
        or len(set(modes)) != len(modes)
        or mode not in modes
    ):
        raise ValueError("selected mode must be declared in manifest")
    declared = manifest.get("sample_ids")
    actual = [row.get("run_id") for row in inputs.records]
    if (
        not isinstance(declared, list)
        or any(not isinstance(s, str) or not s for s in declared)
        or len(set(declared)) != len(declared)
        or len(actual) != len(set(actual))
        or set(declared) != set(actual)
    ):
        raise ValueError("declared sample IDs do not match exported trials")
    repeats = manifest.get("repeats")
    if type(repeats) is not int or not 1 <= repeats <= 10_000:
        raise ValueError("positive bounded repeat count required")
    questions = inputs.metadata.get("questions")
    if not isinstance(questions, dict) or not 1 <= len(questions) * repeats <= 10_000:
        raise ValueError("declared task/repeat matrix requires 1..10000 trials")
    # Existing comparison owns record/score validation. Do not invent a second
    # permissive score contract at the regression boundary.
    compare_records(
        inputs.records,
        inputs.scores,
        metadata=inputs.metadata["questions"],
        resamples=100,
    )
    selected = [r for r in inputs.records if r["mode"] == mode]
    expected = {
        (qid, i) for qid in inputs.metadata["questions"] for i in range(repeats)
    }
    observed = {(r["question_id"], r["repeat_index"]) for r in selected}
    if observed != expected or any(r["mode"] not in modes for r in inputs.records):
        raise ValueError(
            "selected trial matrix differs from declared task/repeat matrix"
        )
    return selected


def _normalized(inputs, selected, label):
    rows, scores = [], []
    by_id = {s["run_id"]: s for s in inputs.scores}
    for row in selected:
        run_id = f"{label}:{row['run_id']}"
        rows.append({**row, "run_id": run_id, "mode": label})
        if row["run_id"] in by_id:
            scores.append({**by_id[row["run_id"]], "run_id": run_id, "mode": label})
    return rows, scores


def _quality_check(group, name, rule, policy):
    stats = group["comparisons"]["candidate"][name]["all_output"]
    coverage = {
        label: group["systems"][label]["quality"][name]["coverage"]
        for label in ("baseline", "candidate")
    }
    deltas = stats["task_differences"]
    regressed = sorted(q for q, d in deltas.items() if d < -1e-12)
    improved = sorted(q for q, d in deltas.items() if d > 1e-12)
    enough = stats["paired_tasks"] >= policy.min_paired_tasks and all(
        c >= policy.min_score_coverage for c in coverage.values()
    )
    protected = sorted(
        q
        for q, d in deltas.items()
        if rule.max_task_drop is not None and d < -rule.max_task_drop - 1e-12
    )
    mean_regressed = enough and stats["difference"] < -rule.max_drop - 1e-12
    if protected or mean_regressed:
        status, reason = "fail", "observed quality drop exceeds policy tolerance"
    elif not enough:
        status, reason = "inconclusive", "insufficient paired tasks or score coverage"
    else:
        status, reason = "pass", "observed quality drop is within policy tolerance"
    return {
        "name": name,
        "status": status,
        "reason": reason,
        "delta": stats["difference"],
        "interval_95": stats["interval_95"],
        "paired_tasks": stats["paired_tasks"],
        "coverage": coverage,
        "excluded_tasks": stats["excluded_tasks"],
        "task_differences": deltas,
        "regressed_tasks": regressed,
        "improved_tasks": improved,
        "protected_regressions": protected,
        **rule.model_dump(),
    }


def _operational_checks(group, policy):
    left, right = (group["systems"][s] for s in ("baseline", "candidate"))
    checks = []
    for name, field, tolerance in (
        ("completion_rate", "completed_runs", policy.max_completion_rate_drop),
        ("answered_rate", "answered_runs", policy.max_answered_rate_drop),
    ):
        a, b = (
            left[field] / left["attempted_runs"],
            right[field] / right["attempted_runs"],
        )
        checks.append(
            {
                "name": name,
                "baseline": a,
                "candidate": b,
                "delta": b - a,
                "max_drop": tolerance,
                "status": "fail" if b - a < -tolerance - 1e-12 else "pass",
                "reason": "operational rate only; not semantic task success",
            }
        )
    if policy.max_latency_ratio is not None:
        a, b = left["latency_ms"]["p50"], right["latency_ms"]["p50"]
        ratio = b / a if a else None
        checks.append(
            {
                "name": "latency_p50_ratio",
                "baseline": a,
                "candidate": b,
                "ratio": ratio,
                "max_ratio": policy.max_latency_ratio,
                "status": "inconclusive"
                if ratio is None
                else ("fail" if ratio > policy.max_latency_ratio else "pass"),
                "reason": "observed latency ratio; no significance claim",
            }
        )
    return checks


def evaluate_regression(
    baseline: AnalysisInputs,
    candidate: AnalysisInputs,
    *,
    baseline_mode: str,
    candidate_mode: str,
    policy: RegressionPolicy,
    seed=0,
    resamples=2000,
) -> dict:
    left_manifest, right_manifest = (
        baseline.payload["manifest"],
        candidate.payload["manifest"],
    )
    for name in CONTROL_FIELDS:
        if (
            name not in left_manifest
            or name not in right_manifest
            or left_manifest[name] != right_manifest[name]
        ):
            raise ValueError(f"experiment control mismatch: {name}")
    if left_manifest.get("benchmark") != right_manifest.get("benchmark"):
        raise ValueError("benchmark identity or split mismatch")
    if left_manifest.get("execution_profile") != right_manifest.get("execution_profile"):
        raise ValueError("experiment control mismatch: execution_profile")
    if baseline.metadata != candidate.metadata:
        raise ValueError("task metadata mismatch")
    for name in policy.metrics:
        a, b = baseline.metric_judges.get(name), candidate.metric_judges.get(name)
        if a is not None and b is not None and a != b:
            raise ValueError(f"judge identity/configuration mismatch: {name}")
    left = _select_trials(baseline, baseline_mode)
    right = _select_trials(candidate, candidate_mode)
    by_task = defaultdict(list)
    for row in left + right:
        by_task[row["question_id"]].append(row.get("question"))
    if any(
        not all(isinstance(q, str) and q == questions[0] for q in questions)
        for questions in by_task.values()
    ):
        raise ValueError("paired question text mismatch")
    left_rows, left_scores = _normalized(baseline, left, "baseline")
    right_rows, right_scores = _normalized(candidate, right, "candidate")
    comparison = compare_records(
        left_rows + right_rows,
        left_scores + right_scores,
        metadata=baseline.metadata["questions"],
        seed=seed,
        resamples=resamples,
    )
    checks = []
    for group in comparison["groups"]:
        identity = {k: group[k] for k in ("dataset", "split", "data_kind")}
        local = _operational_checks(group, policy)
        local.extend(
            _quality_check(group, name, rule, policy)
            for name, rule in policy.metrics.items()
        )
        checks.extend({**identity, **check} for check in local)
    statuses = {c["status"] for c in checks}
    verdict = (
        "fail"
        if "fail" in statuses
        else ("inconclusive" if "inconclusive" in statuses else "pass")
    )
    return {
        "schema_version": 1,
        "verdict": verdict,
        "baseline_mode": baseline_mode,
        "candidate_mode": candidate_mode,
        "policy": policy.model_dump(mode="json"),
        "policy_sha256": _content_hash(policy.model_dump(mode="json")),
        "decision_method": "observed_question_mean_tolerance",
        "checks": checks,
        "comparison": comparison,
        "provenance": {
            "baseline": baseline.provenance,
            "candidate": candidate.provenance,
        },
        "trials": {
            label: [
                {
                    k: row[k]
                    for k in ("question_id", "repeat_index", "run_id", "mode", "status")
                }
                for row in selected
            ]
            for label, selected in (("baseline", left), ("candidate", right))
        },
        "limitations": [
            "Completion and answered rates are operational, not semantic task success.",
            "Point-estimate tolerances are policy checks, not statistical non-inferiority proof.",
            "CI95 bootstraps questions; repeats are averaged within each question.",
            "A pass establishes no absolute quality floor or general population improvement.",
            "Hashes verify artifact consistency, not independent authenticity or judge accuracy.",
        ],
    }
