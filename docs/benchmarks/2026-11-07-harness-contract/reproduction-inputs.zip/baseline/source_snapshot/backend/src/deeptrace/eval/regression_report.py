"""Human-readable decisions and task/trial drill-down for regression reports."""

from html import escape


def _cell(value):
    if value is None:
        return "N/A"
    return (
        escape(str(value), quote=False)
        .replace("|", "\\|")
        .replace("\n", " ")
        .replace("`", "\\`")
    )


def render_regression(report):
    lines = [
        f"# Agent regression: {report['verdict'].upper()}",
        "",
        f"Policy: {_cell(report['policy']['name'])} (`{report['policy_sha256']}`).",
        f"Strategies: {_cell(report['baseline_mode'])} -> {_cell(report['candidate_mode'])}.",
        "",
        "The decision checks configured observed tolerances. It is not proof of "
        "statistical non-inferiority or an absolute quality certification.",
        "",
        "| dataset / split / kind | check | verdict | delta or ratio | paired tasks | coverage (old/new) | reason |",
        "| --- | --- | --- | ---: | ---: | --- | --- |",
    ]
    for check in report["checks"]:
        coverage = check.get("coverage", {})
        identity = " / ".join(check[k] for k in ("dataset", "split", "data_kind"))
        cells = [
            identity,
            check["name"],
            check["status"],
            check.get("delta", check.get("ratio")),
            check.get("paired_tasks"),
            f"{coverage.get('baseline', 'N/A')} / {coverage.get('candidate', 'N/A')}",
            check["reason"],
        ]
        lines.append("| " + " | ".join(_cell(c) for c in cells) + " |")
    lines.extend(
        [
            "",
            "## Task changes",
            "",
            "| dataset / split | metric | question | delta | change |",
            "| --- | --- | --- | ---: | --- |",
        ]
    )
    for check in report["checks"]:
        for qid, delta in check.get("task_differences", {}).items():
            change = (
                "regressed"
                if delta < -1e-12
                else ("improved" if delta > 1e-12 else "unchanged")
            )
            cells = [
                f"{check['dataset']} / {check['split']}",
                check["name"],
                qid,
                delta,
                change,
            ]
            lines.append("| " + " | ".join(_cell(c) for c in cells) + " |")
        if check.get("excluded_tasks"):
            lines.append(
                f"\nExcluded for {_cell(check['name'])}: "
                + ", ".join(_cell(q) for q in check["excluded_tasks"])
                + ".\n"
            )
    lines.extend(
        [
            "",
            "## Original trials",
            "",
            "Full answers, evidence and trajectories remain in the source quality exports.",
            "",
            "| side | question | repeat | original run ID | status |",
            "| --- | --- | ---: | --- | --- |",
        ]
    )
    for side, rows in report["trials"].items():
        for row in rows:
            cells = [
                side,
                row["question_id"],
                row["repeat_index"],
                row["run_id"],
                row["status"],
            ]
            lines.append("| " + " | ".join(_cell(c) for c in cells) + " |")
    lines.extend(
        [
            "",
            "## Resources",
            "",
            "| dataset / split / kind | side | runs | p50 ms | p95 ms | input tokens | output tokens | provider attempts |",
            "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |",
        ]
    )
    for group in report["comparison"]["groups"]:
        for side, stats in group["systems"].items():
            cells = [
                " / ".join(group[k] for k in ("dataset", "split", "data_kind")),
                side,
                stats["attempted_runs"],
                stats["latency_ms"]["p50"],
                stats["latency_ms"]["p95"],
                *[
                    stats["usage"][m]["total"]
                    for m in ("input_tokens", "output_tokens", "provider_attempts")
                ],
            ]
            lines.append("| " + " | ".join(_cell(c) for c in cells) + " |")
    lines.extend(
        [
            "",
            "CI95, all-output/completed-only views, observed usage subtotals "
            "and complete scoring provenance are in regression.json.",
            "",
            "## Source artifacts",
            "",
        ]
    )
    for name, path in report["provenance"].get("files", {}).items():
        lines.append(f"- {_cell(name)}: {_cell(path)}")
    lines.extend(["", "## Limits", ""])
    lines.extend(f"- {line}" for line in report["limitations"])
    return "\n".join(lines) + "\n"
