"""Bounded source outlines and host-resolved rereads, never semantic evidence."""

import hashlib
from itertools import zip_longest

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from deeptrace.domain.evidence import Evidence
from deeptrace.domain.evidence_anchor import ReadEvidenceAnchor
from deeptrace.harness.context import HarnessContext
from deeptrace.tools.evidence_views import _source_blocks


class SourceReadChoice(BaseModel):
    model_config = ConfigDict(extra="forbid")
    block_id: str = Field(min_length=1, max_length=100)
    target_requirement_ids: list[str] = Field(min_length=1, max_length=6)


class SourceReadAction(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    anchor: ReadEvidenceAnchor
    target_requirement_ids: list[str] = Field(default_factory=list, max_length=6)


async def build_source_outline(
    context: HarnessContext,
    records: list[Evidence],
    eligibility: dict[str, str],
) -> tuple[list[dict], dict[str, SourceReadAction], list[str]]:
    candidates, diagnostics = [], []
    admitted = [r for r in records if eligibility.get(r.id) != "ineligible"]
    if len(admitted) > 8:
        diagnostics.append("reread_outline_sources_omitted")
    for record in admitted[:8]:
        try:
            body = await context.evidence_store.read_body(
                context.workspace_id, record.id
            )
        except Exception:  # noqa: BLE001 - isolate a source, not cancellation
            diagnostics.append(f"reread_outline_unavailable:{record.id}")
            continue
        ranges = []
        for start, end in _source_blocks(body):
            if end - start > 900:
                diagnostics.append(f"reread_outline_oversized:{record.id}:{start}")
            elif body[start:end].strip():
                ranges.append((start, end))
        if len(ranges) > 32:
            diagnostics.append(f"reread_outline_blocks_omitted:{record.id}")
            # Sample the whole page rather than hiding every later section.
            ranges = [ranges[i * (len(ranges) - 1) // 31] for i in range(32)]
        local = []
        for start, end in ranges:
            anchor = ReadEvidenceAnchor(
                evidence_id=record.id,
                version=record.version,
                content_hash=record.content_hash,
                start=start,
                end=end,
            )
            key = (
                "b-" + hashlib.sha256(repr(anchor.range_key).encode()).hexdigest()[:20]
            )
            text = body[start:end].strip()
            preview = text if len(text) <= 200 else text[:150] + " … " + text[-47:]
            local.append(
                (
                    {
                        "block_id": key,
                        "evidence_id": record.id,
                        "title": record.title[:120],
                        "url": record.canonical_url[:400],
                        "start": start,
                        "end": end,
                        "preview": preview,
                    },
                    SourceReadAction(anchor=anchor),
                )
            )
        candidates.append(local)
    ordered = [entry for rank in zip_longest(*candidates) for entry in rank if entry]
    if len(ordered) > 128:
        diagnostics.append("reread_outline_capacity_omitted")
    entries = ordered[:128]
    return (
        [e for e, _ in entries],
        {e["block_id"]: a for e, a in entries},
        list(dict.fromkeys(diagnostics)),
    )


def resolve_source_reads(
    payload: dict | None,
    blocks: dict[str, SourceReadAction],
    *,
    gap_ids: set[str],
    requirement_ids: set[str],
) -> list[SourceReadAction]:
    if not gap_ids <= requirement_ids:
        raise ValueError("invalid_gap_ids")
    candidates = (payload or {}).get("reads")
    if not isinstance(candidates, list):
        return []
    actions, seen = [], set()
    for candidate in candidates[:24]:
        try:
            choice = SourceReadChoice.model_validate(candidate)
        except ValidationError:
            continue
        targets = choice.target_requirement_ids
        if (
            choice.block_id not in blocks
            or choice.block_id in seen
            or len(set(targets)) != len(targets)
            or not set(targets) <= requirement_ids
        ):
            continue
        remaining = [r for r in targets if r in gap_ids]
        if not remaining:
            continue
        actions.append(
            blocks[choice.block_id].model_copy(
                update={"target_requirement_ids": remaining}
            )
        )
        seen.add(choice.block_id)
        if len(actions) == 2:
            break
    return actions
