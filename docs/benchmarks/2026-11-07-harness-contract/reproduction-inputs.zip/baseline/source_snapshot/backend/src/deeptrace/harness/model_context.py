"""Task metadata and model input estimates independent of a domain prompt."""

import json
from collections.abc import Sequence
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from deeptrace.harness.token_budget import count_tokens


class TaskContext(BaseModel):
    model_config = ConfigDict(extra="forbid")
    task: str = Field(min_length=1)
    constraints: list[str]


def message_tokens(messages: list[Any], tools: Sequence[Any] = ()) -> int:
    payload = [message.model_dump(mode="json") for message in messages]
    return count_tokens(json.dumps([payload, tools], ensure_ascii=False, default=str))
