"""Offline CI gate: 0=pass, 1=regression, 2=invalid or insufficient evidence."""

from __future__ import annotations

import argparse
from pathlib import Path

from deeptrace.eval.analysis_inputs import load_analysis_inputs, read_json
from deeptrace.eval.artifacts import atomic_json
from deeptrace.eval.regression import RegressionPolicy, evaluate_regression
from deeptrace.eval.regression_report import render_regression


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--baseline", required=True, help="baseline quality_eval.json v2"
    )
    parser.add_argument(
        "--candidate", required=True, help="candidate quality_eval.json v2"
    )
    parser.add_argument("--baseline-scores", action="append", required=True)
    parser.add_argument("--candidate-scores", action="append", required=True)
    parser.add_argument("--metadata", required=True, help="shared analysis card")
    parser.add_argument("--baseline-mode", required=True)
    parser.add_argument("--candidate-mode", required=True)
    parser.add_argument(
        "--policy", required=True, help="explicit RegressionPolicy JSON"
    )
    parser.add_argument("--out", required=True, help="new or empty report directory")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--resamples", type=int, default=2000)
    args = parser.parse_args(argv)
    try:
        policy = RegressionPolicy.model_validate(read_json(args.policy))
        baseline = load_analysis_inputs(
            args.baseline, args.baseline_scores, args.metadata
        )
        candidate = load_analysis_inputs(
            args.candidate, args.candidate_scores, args.metadata
        )
        report = evaluate_regression(
            baseline,
            candidate,
            baseline_mode=args.baseline_mode,
            candidate_mode=args.candidate_mode,
            policy=policy,
            seed=args.seed,
            resamples=args.resamples,
        )
        report["provenance"]["files"] = {
            name: str(Path(value).resolve())
            for name, value in (
                ("baseline", args.baseline),
                ("candidate", args.candidate),
                ("metadata", args.metadata),
                ("policy", args.policy),
            )
        }
        output = Path(args.out).absolute()
        if output.is_symlink() or any(p.is_symlink() for p in output.parents):
            raise ValueError("symlink report output refused")
        if output.exists() and (not output.is_dir() or any(output.iterdir())):
            raise ValueError("report output must be an empty directory")
        markdown = render_regression(report)
        output.mkdir(parents=True, exist_ok=True)
        atomic_json(output / "regression.json", report)
        (output / "regression.md").write_text(markdown, encoding="utf-8")
    except (ValueError, KeyError, TypeError, OSError) as exc:
        parser.error(f"invalid regression input or output: {exc}")
    print(markdown)
    return {"pass": 0, "fail": 1, "inconclusive": 2}[report["verdict"]]


if __name__ == "__main__":
    raise SystemExit(main())
