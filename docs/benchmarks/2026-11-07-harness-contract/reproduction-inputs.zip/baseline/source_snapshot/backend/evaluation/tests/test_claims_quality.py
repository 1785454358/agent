"""Custom claim/citation metrics with controlled judge responses; no network."""

import asyncio
import copy
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import claims_quality
from claims_quality import (
    _citation_items,
    _sentence_spans,
    parse_json_object,
    score_citation_accuracy,
    score_claim_groundedness,
    score_metric,
)
from eval_common import cache_key

JUDGE = dict(model="judge", max_tokens=2048)


def controlled_call(responses):
    queue = list(responses)
    calls = []

    async def call(**kwargs):
        calls.append(kwargs)
        return SimpleNamespace(
            choices=[
                SimpleNamespace(message=SimpleNamespace(content=queue.pop(0)))
            ],
            usage=None,
        )

    return call, calls


def claims_response(grounded, count=1, text="Claim."):
    return json.dumps(
        {"claims": [{"text": text, "grounded": grounded} for _ in range(count)]}
    )


def citation_response(supported):
    return json.dumps({"supported": supported})


def sample():
    return dict(
        record=dict(
            run_id="r",
            question_id="q",
            mode="baseline",
            status="completed",
            question="Explain checkpoint",
            answer="Checkpoint requires thread_id.[1]",
            evidence=[
                dict(
                    id="e1",
                    url="https://example.com/docs",
                    title="Docs",
                    body="Checkpoint requires thread_id.",
                    selected_for_outcome=True,
                )
            ],
            artifact_errors=[],
            cited_evidence_ids=["e1"],
        ),
        reference=dict(id="q", question="Explain checkpoint", gold_answer="x"),
    )


def run_claims(item, responses, max_claims=40):
    call, calls = controlled_call(responses)
    result = asyncio.run(
        score_claim_groundedness(
            item, call, model=JUDGE["model"], max_tokens=JUDGE["max_tokens"],
            max_claims=max_claims,
        )
    )
    return result, calls


def run_citations(item, responses, max_citations=16):
    call, calls = controlled_call(responses)
    result = asyncio.run(
        score_citation_accuracy(
            item, call, model=JUDGE["model"], max_tokens=JUDGE["max_tokens"],
            max_citations=max_citations,
        )
    )
    return result, calls


def test_claim_groundedness_is_discriminative():
    good, _ = run_claims(sample(), [claims_response(True)])
    bad, _ = run_claims(sample(), [claims_response(False)])
    assert good["status"] == bad["status"] == "ok"
    assert good["value"] == 1.0
    assert bad["value"] == 0.0
    assert good["details"]["grounded_count"] == 1


def test_claims_are_truncated_to_limit_and_text_length():
    long_text = "x" * 300
    result, _ = run_claims(
        sample(), [claims_response(True, count=50, text=long_text)], max_claims=40
    )
    assert result["status"] == "ok"
    assert result["details"]["claim_count"] == 40
    assert result["details"]["claims_truncated"] is True
    assert all(len(claim["text"]) == 200 for claim in result["details"]["claims"])


def test_missing_selected_evidence_is_not_applicable_without_judge_calls():
    item = sample()
    item["record"]["evidence"] = []
    result, calls = run_claims(item, [])
    assert result == {
        "status": "not_applicable",
        "value": None,
        "reason": "missing_or_incomplete_selected_evidence",
    }
    assert calls == []


def test_artifact_errors_block_claims_metric():
    item = sample()
    item["record"]["artifact_errors"] = ["KeyError"]
    result, calls = run_claims(item, [])
    assert result["reason"] == "missing_or_incomplete_selected_evidence"
    assert calls == []


def test_empty_claims_is_error_without_retry():
    result, calls = run_claims(sample(), ['{"claims": []}'])
    assert result == {"status": "error", "value": None, "reason": "empty_claims"}
    assert len(calls) == 1


def test_malformed_claims_items_are_skipped_not_fatal():
    content = json.dumps(
        {
            "claims": [
                {"text": "ok", "grounded": True},
                {"text": 5, "grounded": True},
                "junk",
                {"text": "no verdict"},
            ]
        }
    )
    result, _ = run_claims(sample(), [content])
    assert result["status"] == "ok"
    assert result["value"] == 1.0
    assert result["details"]["malformed_claims"] == 3


def test_parse_failure_retries_once_then_succeeds():
    result, calls = run_claims(
        sample(), ["not json", claims_response(True)]
    )
    assert result["status"] == "ok" and result["value"] == 1.0
    assert len(calls) == 2


def test_parse_failure_after_bounded_retry_is_error():
    result, calls = run_claims(sample(), ["no", "nope"])
    assert result == {"status": "error", "value": None, "reason": "judge_parse"}
    assert len(calls) == 2


def test_non_list_claims_is_error():
    result, calls = run_claims(sample(), ['{"claims": "nope"}'])
    assert result == {"status": "error", "value": None, "reason": "invalid_claims"}
    assert len(calls) == 1


def test_large_used_evidence_is_not_silently_truncated():
    item = sample()
    item["record"]["evidence"][0]["body"] += "x" * 100_001
    result, calls = run_claims(item, [])
    assert result == {
        "status": "not_applicable",
        "value": None,
        "reason": "quality_input_size_limit",
    }
    assert calls == []


def test_parse_json_object_is_bounded_and_object_only():
    assert parse_json_object(None) is None
    assert parse_json_object("no json") is None
    assert parse_json_object("[1, 2]") is None
    assert parse_json_object('{"a": 1}') == {"a": 1}
    assert parse_json_object('前言 {"supported": true} 后语') == {"supported": True}


def test_sentence_spans_keep_trailing_markers_attached():
    text = "First claim.[2] Second claim.[1] Tail"
    spans = _sentence_spans(text)
    assert [text[span[0] : span[1]] for span in spans] == [
        "First claim.[2]",
        " Second claim.[1]",
        " Tail",
    ]
    spans = _sentence_spans("未结束的句子")
    assert spans == [(0, 6)]


@pytest.mark.parametrize("claim", [
    "Python requires `langgraph>=1.2`; JS requires `@langchain/langgraph>=1.4.0`.",
    "Import `TimeoutPolicy` from `langgraph.types`.",
    "Call ``graph.invoke(`input`)!`` to resume.",
    "Python requires langgraph 1.2.3.",
])
def test_citation_judge_receives_the_whole_technical_claim(claim):
    record = sample()["record"]
    record["answer"] = f"{claim}[1] Another sentence."
    items, total, outcome = _citation_items(record, max_citations=12)
    assert outcome is None
    assert total == 1
    assert items[0]["sentence"] == claim


def test_inline_code_punctuation_does_not_merge_separate_cited_sentences():
    record = sample()["record"]
    record["answer"] = "Use `a.b`.[1] Avoid `c.d`.[1]"
    items, total, outcome = _citation_items(record, max_citations=12)
    assert outcome is None
    assert total == 2
    assert [item["sentence"] for item in items] == ["Use `a.b`.", "Avoid `c.d`."]


def test_citation_items_follow_first_appearance_and_truncate():
    record = dict(
        answer="A claim.[2] B claim.[1] C claim.[2] D claim.[3]",
        cited_evidence_ids=["e1", "e2", "e3"],
        evidence=[
            dict(id="e1", title="A", url="u1", body="one"),
            dict(id="e2", title="B", url="u2", body="two"),
            dict(id="e3", title="C", url="u3", body="three"),
        ],
    )
    items, unique_total, outcome = _citation_items(record, max_citations=2)
    assert outcome is None
    assert unique_total == 4
    assert [(item["number"], item["evidence_id"]) for item in items] == [
        (2, "e2"),
        (1, "e1"),
    ]
    assert items[0]["sentence"] == "A claim."
    assert items[1]["sentence"] == "B claim."


def test_citation_marker_out_of_range_is_error():
    record = dict(
        answer="Claim.[4]",
        cited_evidence_ids=["e1"],
        evidence=[dict(id="e1", title="A", url="u", body="one")],
    )
    items, unique_total, outcome = _citation_items(record, max_citations=16)
    assert outcome == ("error", "marker_out_of_range")
    assert items is None


def test_cited_evidence_missing_is_error():
    item = sample()
    item["record"]["evidence"] = []  # cited id e1 no longer resolvable
    result, calls = run_citations(item, [])
    assert result == {
        "status": "error",
        "value": None,
        "reason": "cited_evidence_missing",
    }
    assert calls == []


def test_empty_cited_body_is_not_applicable():
    item = sample()
    item["record"]["evidence"][0]["body"] = "   "
    result, calls = run_citations(item, [])
    assert result == {
        "status": "not_applicable",
        "value": None,
        "reason": "empty_cited_body",
    }
    assert calls == []


def test_no_citations_is_not_applicable():
    item = sample()
    item["record"]["answer"] = "No markers here."
    item["record"]["cited_evidence_ids"] = []
    result, calls = run_citations(item, [])
    assert result == {
        "status": "not_applicable",
        "value": None,
        "reason": "no_citations",
    }
    assert calls == []


def test_citation_accuracy_is_discriminative_and_reports_counts():
    good, calls = run_citations(sample(), [citation_response(True)])
    bad, _ = run_citations(sample(), [citation_response(False)])
    assert good["status"] == bad["status"] == "ok"
    assert good["value"] == 1.0
    assert bad["value"] == 0.0
    assert good["details"]["unique_citation_count"] == 1
    assert good["details"]["supported_citation_count"] == 1
    assert len(calls) == 1
    prompt = calls[0]["messages"][0]["content"]
    assert "Checkpoint requires thread_id." in prompt
    assert "[1]" not in prompt.split("来源正文")[0]


def test_each_sentence_source_pair_is_checked_even_when_source_repeats():
    item = sample()
    item["record"]["answer"] = "A claim.[1] B claim.[2] A again.[1]"
    item["record"]["cited_evidence_ids"] = ["e1", "e2"]
    item["record"]["evidence"].append(
        dict(id="e2", title="Docs2", url="https://example.com/2", body="Second body.")
    )
    result, calls = run_citations(
        item, [citation_response(True), citation_response(False), citation_response(True)]
    )
    assert result["status"] == "ok"
    assert result["value"] == pytest.approx(2 / 3)
    assert len(calls) == 3
    first_prompt = calls[0]["messages"][0]["content"]
    second_prompt = calls[1]["messages"][0]["content"]
    assert "A claim." in first_prompt and "Checkpoint requires thread_id." in (
        first_prompt
    )
    assert "B claim." in second_prompt and "Second body." in second_prompt


def test_citation_non_boolean_verdict_is_error():
    result, calls = run_citations(sample(), ['{"supported": "yes"}'])
    assert result == {"status": "error", "value": None, "reason": "judge_parse"}
    assert len(calls) == 1


def test_repeated_source_checks_the_later_unsupported_sentence_too():
    item = sample()
    item["record"]["answer"] = "Checkpoint requires thread_id.[1] Checkpoints guarantee zero data loss.[1]"
    result, calls = run_citations(item, [citation_response(True), citation_response(False)])
    assert result["value"] == 0.5
    assert len(calls) == 2
    assert "guarantee zero data loss" in calls[1]["messages"][0]["content"]
    assert result["details"]["unique_citation_count"] == 1
    assert result["details"]["citation_use_count"] == 2


@pytest.mark.parametrize("code", [
    "`items[99]`", "```python\nitems[99]\n```", "~~~python\nitems[99]\n~~~",
])
def test_code_indices_are_excluded_from_independent_citation_audit(code):
    item = sample()
    item["record"]["answer"] = code + "\n\nCheckpoint requires thread_id.[1]"
    result, calls = run_citations(item, [citation_response(True)])
    assert result["status"] == "ok"
    assert len(calls) == 1


def test_support_beyond_the_first_6000_characters_is_not_silently_hidden():
    item = sample()
    item["record"]["evidence"][0]["body"] = "Background. " * 700 + "Checkpoint requires thread_id."
    result, calls = run_citations(item, [citation_response(True)])
    assert result["value"] == 1
    assert "Checkpoint requires thread_id." in calls[0]["messages"][0]["content"].split("来源正文：\n")[1]


def test_long_citing_sentence_keeps_its_late_exception():
    item = sample()
    item["record"]["answer"] = "A " * 180 + "only under this exact condition[1]."
    result, calls = run_citations(item, [citation_response(False)])
    assert "only under this exact condition" in calls[0]["messages"][0]["content"]
    assert result["value"] == 0


def test_sampled_citation_uses_are_explicitly_distinguished_from_full_audit():
    item = sample()
    item["record"]["answer"] = "First.[1] Second.[1] Third.[1]"
    result, calls = run_citations(item, [citation_response(True)], max_citations=1)
    assert len(calls) == 1
    assert result["details"]["citation_use_count"] == 3
    assert result["details"]["citations_truncated"] is True
    assert result["details"]["score_scope"] == "sampled_citation_uses"


def test_overlong_sentence_is_unmeasured_instead_of_scoring_a_truncated_claim():
    item = sample()
    item["record"]["answer"] = "x" * 2200 + "[1]"
    result, calls = run_citations(item, [])
    assert calls == []
    assert result["status"] == "not_applicable"
    assert result["reason"] == "citation_sentence_size_limit"


def test_citation_input_limit_includes_rubric_and_prompt_formatting():
    item = sample()
    item["record"]["evidence"][0]["body"] = "x" * 99900
    result, calls = run_citations(item, [])
    assert calls == []
    assert result["status"] == "not_applicable"
    assert result["reason"] == "quality_input_size_limit"


def test_score_metric_dispatches_and_rejects_unknown():
    call, _ = controlled_call([claims_response(True)])
    result = asyncio.run(
        score_metric(
            sample(),
            "claim_groundedness",
            call,
            model=JUDGE["model"],
            max_tokens=2048,
            max_claims=40,
            max_citations=16,
        )
    )
    assert result["status"] == "ok"
    with pytest.raises(ValueError):
        asyncio.run(
            score_metric(
                sample(),
                "unknown",
                call,
                model=JUDGE["model"],
                max_tokens=2048,
                max_claims=40,
                max_citations=16,
            )
        )


def test_cache_identity_covers_evidence_reference_and_judge():
    item = sample()
    scorer = str(Path(claims_quality.__file__).resolve())
    kwargs = dict(
        adapter_version=claims_quality.ADAPTER_VERSION, scorer_path=scorer
    )
    original = cache_key(item, "claim_groundedness", {"model": "a"}, **kwargs)
    for field in ("evidence", "answer", "judge", "metric"):
        changed = copy.deepcopy(item)
        judge, metric = {"model": "a"}, "claim_groundedness"
        if field == "evidence":
            changed["record"]["evidence"][0]["body"] += " changed"
        elif field == "answer":
            changed["record"]["answer"] += " changed"
        elif field == "judge":
            judge = {"model": "b"}
        else:
            metric = "citation_accuracy"
        assert (
            cache_key(changed, metric, judge, **kwargs) != original
        ), field


def test_judge_calls_are_metered_cached_and_scores_written(tmp_path, monkeypatch):
    import openai
    from openai.types.chat import ChatCompletion

    calls = []
    original_client = openai.AsyncOpenAI

    class ControlledClient(original_client):
        def __init__(self, **kwargs):
            assert kwargs["max_retries"] == 0
            super().__init__(**kwargs)

            async def valid_response(**request):
                calls.append(request)
                return ChatCompletion(
                    id="test",
                    object="chat.completion",
                    created=0,
                    model="test",
                    choices=[
                        dict(
                            index=0,
                            finish_reason="stop",
                            message=dict(
                                role="assistant",
                                content=json.dumps(
                                    {
                                        "claims": [
                                            {"text": "a", "grounded": True}
                                        ],
                                        "supported": True,
                                    }
                                ),
                            ),
                        )
                    ],
                    usage=dict(prompt_tokens=10, completion_tokens=3, total_tokens=13),
                )

            self.chat.completions.create = valid_response

    monkeypatch.setattr(openai, "AsyncOpenAI", ControlledClient)
    item = sample()
    payload = dict(identity_sha256="experiment", samples=[item])
    credentials = dict(key="fake", url="https://example.com/v1")
    judge = dict(model="test", max_tokens=2048)

    async def run():
        from claims_quality import evaluate

        return await evaluate(
            payload,
            tmp_path,
            judge,
            credentials,
            4,
            max_claims=40,
            max_citations=16,
        )

    first = asyncio.run(run())
    # One claims call plus one citation call per sample; nothing else.
    assert len(calls) == first["usage"]["provider_attempts"] == 2
    assert first["usage"]["input_tokens"] == 20
    assert (tmp_path / "claims_scores.json").exists()
    report = json.loads((tmp_path / "claims_scores.json").read_text(encoding="utf-8"))
    assert set(report["results"][0]["metrics"]) == {
        "claim_groundedness",
        "citation_accuracy",
    }
    second = asyncio.run(run())
    assert len(calls) == 2  # fully cached; no new provider attempts
    assert second == first
