"""Shared infrastructure for the isolated evaluation scorers.

Dependency-light helpers extracted so isolated scorers (ragas_quality.py,
claims_quality.py) reuse the same ledger, cache and integrity discipline.
Never import the production deeptrace package from here.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import os
import tempfile
from pathlib import Path
from urllib.parse import urlsplit


def digest(value):
    return hashlib.sha256(
        json.dumps(
            value,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        ).encode()
    ).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    name = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, delete=False
        ) as handle:
            name = handle.name
            json.dump(
                value, handle, ensure_ascii=False, sort_keys=True, allow_nan=False
            )
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        if name and Path(name).exists():
            Path(name).unlink()


class AttemptLedger:
    """Counts each SDK-facing attempt, including validation retries."""

    def __init__(self, path, limit):
        if type(limit) is not int or limit < 1:
            raise ValueError("positive attempt limit required")
        self.path = Path(path)
        self.limit = limit
        self.lock = asyncio.Lock()
        if self.path.is_symlink():
            raise ValueError("symlink ledger refused")
        self.attempts = (
            json.loads(self.path.read_text(encoding="utf-8"))
            if self.path.exists()
            else []
        )
        if not isinstance(self.attempts, list) or len(self.attempts) > limit:
            raise ValueError("invalid prior attempt ledger")
        for entry in self.attempts:
            if not isinstance(entry, dict) or entry.get("status") not in {
                "in_flight",
                "ok",
                "error",
                "cancelled",
            }:
                raise ValueError("invalid attempt record")
            for key in ("input_tokens", "output_tokens"):
                count = entry.get(key)
                if count is not None and (type(count) is not int or count < 0):
                    raise ValueError("invalid usage record")

    async def invoke(self, raw, **kwargs):
        async with self.lock:
            if len(self.attempts) >= self.limit:
                raise RuntimeError("judge_provider_attempt_budget_exhausted")
            messages = kwargs.get("messages", [])
            if len(json.dumps(messages)) > 800_000:
                raise ValueError("judge_prompt_size_limit")
            entry = {
                "status": "in_flight",
                "input_tokens": None,
                "output_tokens": None,
                "model": kwargs.get("model"),
                "messages": messages,
                "response": None,
            }
            self.attempts.append(entry)
            atomic_json(self.path, self.attempts)
        try:
            result = await raw(**kwargs)
        except BaseException as exc:
            entry.update(
                status="cancelled"
                if isinstance(exc, asyncio.CancelledError)
                else "error",
                error=type(exc).__name__,
            )
            atomic_json(self.path, self.attempts)
            raise
        usage = getattr(result, "usage", None)
        input_tokens = getattr(usage, "prompt_tokens", None)
        output_tokens = getattr(usage, "completion_tokens", None)
        valid = all(type(n) is int and n >= 0 for n in (input_tokens, output_tokens))
        entry.update(
            status="ok",
            input_tokens=input_tokens if valid else None,
            output_tokens=output_tokens if valid else None,
        )
        choices = getattr(result, "choices", [])
        content = (
            getattr(getattr(choices[0], "message", None), "content", None)
            if choices
            else None
        )
        if isinstance(content, str) and len(content) <= 100_000:
            entry["response"] = content
        atomic_json(self.path, self.attempts)
        return result

    def snapshot(self):
        measured = [
            a
            for a in self.attempts
            if a["input_tokens"] is not None and a["output_tokens"] is not None
        ]
        missing = len(self.attempts) - len(measured)
        return {
            "provider_attempts": len(self.attempts),
            "max_provider_attempts": self.limit,
            "measured_usage_attempts": len(measured),
            "missing_usage_attempts": missing,
            "observed_input_tokens": sum(a["input_tokens"] for a in measured),
            "observed_output_tokens": sum(a["output_tokens"] for a in measured),
            "input_tokens": None
            if missing
            else sum(a["input_tokens"] for a in measured),
            "output_tokens": None
            if missing
            else sum(a["output_tokens"] for a in measured),
            "cost": None,
        }


def unmeasured(status, reason):
    return {"status": status, "value": None, "reason": reason}


def cache_key(sample, metric, judge_identity, *, adapter_version, scorer_path):
    # Include source and every scoring input; no cache across changed prompts/deps.
    return digest(
        {
            "sample": sample,
            "metric": metric,
            "judge": judge_identity,
            "adapter": adapter_version,
            "scorer_sha256": hashlib.sha256(Path(scorer_path).read_bytes()).hexdigest(),
        }
    )


def validate_export(payload):
    if type(payload.get("schema_version")) is not int or payload["schema_version"] != 2:
        raise ValueError("quality export schema 2 required")
    if not isinstance(payload.get("samples"), list) or not payload["samples"]:
        raise ValueError("nonempty quality samples required")
    if not isinstance(payload.get("manifest"), dict) or digest(
        payload["manifest"]
    ) != payload.get("identity_sha256"):
        raise ValueError("experiment manifest integrity mismatch")
    seen = set()
    for sample in payload["samples"]:
        record, reference = sample["record"], sample["reference"]
        if (
            record["question_id"] != reference["id"]
            or record["question"] != reference["question"]
        ):
            raise ValueError("reference question mismatch")
        if record["run_id"] in seen or record["status"] not in {
            "completed",
            "partial",
            "failed",
        }:
            raise ValueError("invalid or duplicate run")
        seen.add(record["run_id"])


def env_config(env_file):
    from dotenv import dotenv_values

    return {**dotenv_values(env_file), **os.environ}


def judge_request_options(config, model):
    """Credential-free transport settings, recorded as part of judge identity."""
    thinking = config.get("DEEPTRACE_MODEL_THINKING", "auto")
    if thinking not in {"auto", "enabled", "disabled", "provider_default"}:
        raise ValueError("invalid judge thinking configuration")
    name = model.lower()
    if thinking == "auto":
        thinking = "disabled" if name.startswith(
            ("doubao-seed-2.0-lite", "doubao-seed-2-0-lite")
        ) else "provider_default"
    options = {}
    if thinking != "provider_default":
        options["extra_body"] = {"thinking": {"type": thinking}}
    if name.startswith(("deepseek-v4.1-flash", "deepseek-v4-1-flash",
                        "doubao-seed-2.0-lite", "doubao-seed-2-0-lite")):
        options["response_format"] = {"type": "json_object"}
    return options


def credential_free_endpoint(url):
    """Return the urlsplit result for a credential-free HTTP(S) endpoint."""
    parsed = urlsplit(url)
    if (
        parsed.scheme not in {"https", "http"}
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("credential-free HTTP(S) endpoint required")
    return parsed
