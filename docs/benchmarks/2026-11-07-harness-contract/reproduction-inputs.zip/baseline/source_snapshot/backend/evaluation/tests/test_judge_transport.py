import asyncio
import importlib
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import eval_common


@pytest.mark.parametrize("module", ["ragas_quality", "claims_quality"])
def test_independent_scorers_forward_recorded_thinking_options_to_provider(tmp_path, monkeypatch, module):
    import openai
    from openai.types.chat import ChatCompletion

    scorer = importlib.import_module(module)
    requests = []
    original = openai.AsyncOpenAI

    class ControlledClient(original):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

            async def raw(**request):
                requests.append(request)
                return ChatCompletion(
                    id="transport-test", object="chat.completion", created=0,
                    model="controlled", choices=[{
                        "index": 0, "finish_reason": "stop",
                        "message": {"role": "assistant", "content": '{"invalid": true}'},
                    }], usage={"prompt_tokens": 10, "completion_tokens": 3, "total_tokens": 13},
                )

            self.chat.completions.create = raw

    monkeypatch.setattr(openai, "AsyncOpenAI", ControlledClient)
    item = {"record": {
        "run_id": "r", "question_id": "q", "mode": "workflow", "status": "completed",
        "question": "Explain checkpoint", "answer": "Checkpoint needs a thread.[1]",
        "evidence": [{"id": "e", "body": "Checkpoint needs a thread.",
                      "selected_for_outcome": True}],
        "cited_evidence_ids": ["e"], "artifact_errors": [],
    }, "reference": {"gold_answer": "Checkpoint needs a thread."}}
    options = {"extra_body": {"thinking": {"type": "disabled"}},
               "response_format": {"type": "json_object"}}
    judge = {"model": "deepseek-v4.1-flash", "max_tokens": 4096, "request_options": options}
    kwargs = {"max_claims": 40, "max_citations": 12} if module == "claims_quality" else {}
    result = asyncio.run(scorer.evaluate(
        {"identity_sha256": "fixture", "samples": [item]}, tmp_path, judge,
        {"key": "fake", "url": "https://example.com/v1"}, 1, **kwargs,
    ))
    assert result["usage"]["provider_attempts"] == 1
    assert requests[0].get("extra_body") == {"thinking": {"type": "disabled"}}
    assert requests[0]["response_format"] == {"type": "json_object"}
    assert requests[0]["max_tokens"] == 4096


def test_judge_options_follow_config_without_exporting_credentials():
    options = eval_common.judge_request_options(
        {"DEEPTRACE_MODEL_THINKING": "disabled", "OPENAI_API_KEY": "never-export"},
        "deepseek-v4.1-flash",
    )
    assert options == {"extra_body": {"thinking": {"type": "disabled"}},
                       "response_format": {"type": "json_object"}}
    assert eval_common.judge_request_options({}, "generic-model") == {}
    with pytest.raises(ValueError):
        eval_common.judge_request_options({"DEEPTRACE_MODEL_THINKING": "typo"}, "model")
