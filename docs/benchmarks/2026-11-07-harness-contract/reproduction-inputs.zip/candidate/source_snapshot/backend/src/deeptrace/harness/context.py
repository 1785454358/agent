from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol

from deeptrace.domain import (
    Evidence,
    MemoryRecord,
    MemoryStatus,
    MemoryType,
    ToolRequest,
    ToolResult,
)
from deeptrace.domain.memory import MemoryNamespace
from deeptrace.tools.evidence_store import EvidenceDraft
from deeptrace.tools.policy import EvidenceAuthorization, ToolCaller, UrlAuthorization


class ModelGateway(Protocol):
    async def invoke(
        self,
        *,
        role: str,
        messages: list[Any],
        tools: Sequence[Any] | None = None,
    ) -> Any: ...


class ToolGateway(Protocol):
    async def execute(
        self,
        *,
        tenant_id: str,
        caller: ToolCaller,
        request: ToolRequest,
        authorization: UrlAuthorization | None = None,
        provider_id: str = "default",
        refresh: bool = False,
        evidence_authorization: EvidenceAuthorization | None = None,
    ) -> ToolResult: ...


class EvidenceStore(Protocol):
    async def ingest(self, tenant_id: str, draft: EvidenceDraft) -> Evidence: ...

    async def get(self, tenant_id: str, evidence_id: str) -> Evidence: ...

    async def get_many(
        self, tenant_id: str, evidence_ids: Sequence[str]
    ) -> tuple[Evidence, ...]: ...

    async def read_body(self, tenant_id: str, evidence_id: str) -> str: ...


class EventSink(Protocol):
    async def emit(self, event_type: str, payload: dict[str, Any]) -> None: ...


class Clock(Protocol):
    def now(self) -> datetime: ...


class MemoryStorePort(Protocol):
    """Long-term memory port; implementations wrap a LangGraph Store."""

    async def put(self, record: MemoryRecord) -> MemoryRecord: ...

    async def upsert(
        self, record: MemoryRecord, *, allow_reactivate: bool = True
    ) -> MemoryRecord: ...

    async def set_status(
        self, namespace: MemoryNamespace, identity: str, status: MemoryStatus
    ) -> None: ...

    async def delete(self, namespace: MemoryNamespace, identity: str) -> bool: ...

    async def get(
        self, namespace: MemoryNamespace, identity: str
    ) -> MemoryRecord | None: ...

    async def list_namespace(
        self, namespace: MemoryNamespace, *, include_inactive: bool = False
    ) -> list[MemoryRecord]: ...

    async def list_eligible(
        self,
        *,
        namespaces: list[MemoryNamespace],
        memory_types: set[MemoryType],
        now: datetime,
    ) -> list[MemoryRecord]: ...

    async def get_many_by_ids(self, memory_ids: list[str]) -> list[MemoryRecord]: ...


class MemoryRetrieverPort(Protocol):
    async def recall(
        self,
        *,
        namespaces: list[MemoryNamespace],
        memory_types: set[MemoryType],
        query: str,
        now: datetime,
        limit: int,
    ) -> list[MemoryRecord]: ...

    async def index(self, records: Sequence[MemoryRecord]) -> None: ...


@dataclass(frozen=True)
class HarnessContext:
    user_id: str
    workspace_id: str
    model_gateway: ModelGateway
    tool_gateway: ToolGateway
    evidence_store: EvidenceStore
    event_sink: EventSink
    clock: Clock
    memory_store: MemoryStorePort | None = None
    memory_retriever: MemoryRetrieverPort | None = None
    memory_recall_limit: int = 5
    memory_context_tokens: int = 768
    response_max_content_chars: int | None = None
    response_fact_review: bool = False
    research_completion_scope: str = "decomposed"
    research_max_pages: int = 8
